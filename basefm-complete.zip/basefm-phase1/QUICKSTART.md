# baseFM Phase 1 - Quick Start

## 🎯 What You Have

Complete backend infrastructure for live streaming:
- ✅ Database schema (Supabase)
- ✅ Mux streaming integration  
- ✅ API routes for all operations
- ✅ Webhook handling
- ✅ TypeScript types
- ✅ Production-ready architecture

## ⚡ 5-Minute Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Setup Supabase
1. Create project at https://supabase.com
2. Run `supabase-schema.sql` in SQL Editor
3. Copy API keys

### 3. Setup Mux
1. Create account at https://dashboard.mux.com
2. Generate access token (Settings → Access Tokens)
3. Copy Token ID and Secret

### 4. Configure Environment
```bash
cp .env.example .env.local
# Fill in your Supabase and Mux credentials
```

### 5. Run
```bash
npm run dev
```

Visit http://localhost:3000

## 🧪 Test the API

### Create a stream:
```bash
curl -X POST http://localhost:3000/api/streams \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test Stream",
    "djName": "Test DJ",
    "djWalletAddress": "0x1234567890123456789012345678901234567890"
  }'
```

### List streams:
```bash
curl http://localhost:3000/api/streams
```

### Get live streams:
```bash
curl http://localhost:3000/api/streams/live
```

## 📁 File Structure

```
basefm-phase1/
├── app/api/              # API routes
│   ├── streams/          # Stream CRUD + start/stop
│   └── webhooks/         # Mux webhook handler
├── lib/
│   ├── auth/             # Wallet signature verification
│   ├── db/               # Database queries
│   ├── streaming/        # Mux integration
│   └── supabase/         # Supabase client
├── types/                # TypeScript definitions
├── supabase-schema.sql   # Database schema
├── package.json          # Dependencies
├── README.md             # Full documentation
└── DEPLOYMENT_CHECKLIST.md
```

## 🚀 Deploy to Vercel

1. Push to GitHub
2. Import to Vercel
3. Add environment variables
4. Deploy
5. Update Mux webhook URL

See `DEPLOYMENT_CHECKLIST.md` for full details.

## 📚 Documentation

- `README.md` - Complete documentation
- `DEPLOYMENT_CHECKLIST.md` - Production deployment guide
- API Reference in `README.md`

## ✅ What Works Now

- [x] Create streams via API
- [x] Mux generates RTMP URLs automatically
- [x] Webhook updates stream status (LIVE/ENDING/ENDED)
- [x] List streams with filters
- [x] Get live streams
- [x] DJ start/stop operations
- [x] Listener count tracking
- [x] Database persistence

## 🔜 Next: Phase 2 & 3

Phase 2: Test Mux integration with real RTMP stream
Phase 3: Build listener frontend (AudioPlayer with HLS.js)

---

**Need Help?** Check README.md for troubleshooting and full API docs.
