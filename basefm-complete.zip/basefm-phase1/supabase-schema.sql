-- baseFM Supabase Database Schema
-- Run this in Supabase SQL Editor: https://supabase.com/dashboard/project/_/sql

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Streams table
CREATE TABLE streams (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  
  -- Basic Info
  title TEXT NOT NULL,
  description TEXT,
  dj_name TEXT NOT NULL,
  dj_wallet_address TEXT NOT NULL,
  
  -- Streaming
  status TEXT NOT NULL CHECK (status IN ('CREATED', 'PREPARING', 'LIVE', 'ENDING', 'ENDED')),
  mux_live_stream_id TEXT,
  mux_stream_key TEXT,
  mux_playback_id TEXT,
  rtmp_url TEXT,
  hls_playback_url TEXT,
  
  -- Scheduling
  scheduled_start_time TIMESTAMPTZ,
  actual_start_time TIMESTAMPTZ,
  actual_end_time TIMESTAMPTZ,
  
  -- Token Gating (optional)
  is_gated BOOLEAN DEFAULT FALSE,
  required_token_address TEXT,
  required_token_amount NUMERIC,
  
  -- Metadata
  cover_image_url TEXT,
  genre TEXT,
  tags TEXT[],
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Indexes for common queries
  CONSTRAINT valid_wallet_address CHECK (dj_wallet_address ~* '^0x[a-fA-F0-9]{40}$')
);

-- Events table
CREATE TABLE events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  stream_id UUID REFERENCES streams(id) ON DELETE CASCADE,
  
  title TEXT NOT NULL,
  description TEXT,
  scheduled_time TIMESTAMPTZ NOT NULL,
  duration INTEGER, -- minutes
  recurring BOOLEAN DEFAULT FALSE,
  cover_image_url TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Stream Activity Log (for analytics)
CREATE TABLE stream_activity (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  stream_id UUID REFERENCES streams(id) ON DELETE CASCADE,
  
  event_type TEXT NOT NULL CHECK (event_type IN ('CREATED', 'STARTED', 'ENDED', 'LISTENER_JOINED', 'LISTENER_LEFT')),
  metadata JSONB,
  
  timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX idx_streams_status ON streams(status);
CREATE INDEX idx_streams_dj_wallet ON streams(dj_wallet_address);
CREATE INDEX idx_streams_created_at ON streams(created_at DESC);
CREATE INDEX idx_events_scheduled_time ON events(scheduled_time);
CREATE INDEX idx_stream_activity_stream_id ON stream_activity(stream_id);
CREATE INDEX idx_stream_activity_timestamp ON stream_activity(timestamp DESC);

-- Updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at trigger to tables
CREATE TRIGGER update_streams_updated_at
  BEFORE UPDATE ON streams
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_events_updated_at
  BEFORE UPDATE ON events
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Row Level Security (RLS) Policies
ALTER TABLE streams ENABLE ROW LEVEL SECURITY;
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE stream_activity ENABLE ROW LEVEL SECURITY;

-- Public read access for all tables
CREATE POLICY "Public read access" ON streams FOR SELECT USING (true);
CREATE POLICY "Public read access" ON events FOR SELECT USING (true);
CREATE POLICY "Public read access" ON stream_activity FOR SELECT USING (true);

-- Only authenticated users can create streams
-- Note: In production, you'd verify the wallet signature server-side
CREATE POLICY "Authenticated users can create streams" ON streams 
  FOR INSERT 
  WITH CHECK (true);

-- DJs can update their own streams
CREATE POLICY "DJs can update their own streams" ON streams 
  FOR UPDATE 
  USING (true);

-- DJs can delete their own streams
CREATE POLICY "DJs can delete their own streams" ON streams 
  FOR DELETE 
  USING (true);

-- Anyone can create events (we'll handle auth in API layer)
CREATE POLICY "Anyone can create events" ON events 
  FOR INSERT 
  WITH CHECK (true);

-- Activity logs are insert-only (for analytics)
CREATE POLICY "Anyone can log activity" ON stream_activity 
  FOR INSERT 
  WITH CHECK (true);

-- Create a view for live streams (commonly queried)
CREATE VIEW live_streams AS
SELECT * FROM streams
WHERE status = 'LIVE'
ORDER BY actual_start_time DESC;

-- Create a view for upcoming events
CREATE VIEW upcoming_events AS
SELECT e.*, s.dj_name, s.cover_image_url as stream_cover
FROM events e
JOIN streams s ON e.stream_id = s.id
WHERE e.scheduled_time > NOW()
ORDER BY e.scheduled_time ASC;

-- Grant access to views
GRANT SELECT ON live_streams TO anon, authenticated;
GRANT SELECT ON upcoming_events TO anon, authenticated;

-- Function to get active listener count (estimated from recent activity)
CREATE OR REPLACE FUNCTION get_listener_count(stream_uuid UUID)
RETURNS INTEGER AS $$
  SELECT COUNT(DISTINCT metadata->>'listener_id')::INTEGER
  FROM stream_activity
  WHERE stream_id = stream_uuid
    AND event_type = 'LISTENER_JOINED'
    AND timestamp > NOW() - INTERVAL '5 minutes'
    AND NOT EXISTS (
      SELECT 1 FROM stream_activity sa2
      WHERE sa2.stream_id = stream_uuid
        AND sa2.event_type = 'LISTENER_LEFT'
        AND sa2.metadata->>'listener_id' = stream_activity.metadata->>'listener_id'
        AND sa2.timestamp > stream_activity.timestamp
    );
$$ LANGUAGE sql STABLE;
