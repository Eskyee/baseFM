// app/api/streams/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getStreams, createStream } from '@/lib/db/streams';
import { createMuxLiveStream, getMuxPlaybackUrl } from '@/lib/streaming/mux';
import { updateStreamWithMuxDetails } from '@/lib/db/streams';
import { isValidWalletAddress } from '@/lib/auth/wallet';
import type { CreateStreamRequest, CreateStreamResponse } from '@/types/stream';

/**
 * GET /api/streams
 * List all streams with optional filters
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    const status = searchParams.get('status') as any;
    const djWalletAddress = searchParams.get('djWalletAddress');
    const limit = searchParams.get('limit') ? parseInt(searchParams.get('limit')!) : undefined;
    const offset = searchParams.get('offset') ? parseInt(searchParams.get('offset')!) : undefined;

    const streams = await getStreams({
      status,
      djWalletAddress: djWalletAddress || undefined,
      limit,
      offset,
    });

    return NextResponse.json({ streams });
  } catch (error) {
    console.error('Error in GET /api/streams:', error);
    return NextResponse.json(
      { error: 'Failed to fetch streams' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/streams
 * Create a new stream
 */
export async function POST(request: NextRequest) {
  try {
    const body: CreateStreamRequest = await request.json();

    // Validate required fields
    if (!body.title || !body.djName || !body.djWalletAddress) {
      return NextResponse.json(
        { error: 'Missing required fields: title, djName, djWalletAddress' },
        { status: 400 }
      );
    }

    // Validate wallet address format
    if (!isValidWalletAddress(body.djWalletAddress)) {
      return NextResponse.json(
        { error: 'Invalid wallet address format' },
        { status: 400 }
      );
    }

    // Validate token gating configuration
    if (body.isGated) {
      if (!body.requiredTokenAddress) {
        return NextResponse.json(
          { error: 'Token address required for gated streams' },
          { status: 400 }
        );
      }
      if (!body.requiredTokenAmount || body.requiredTokenAmount <= 0) {
        return NextResponse.json(
          { error: 'Valid token amount required for gated streams' },
          { status: 400 }
        );
      }
    }

    // Create stream in database
    const stream = await createStream(body);

    // Create Mux live stream
    try {
      const muxStream = await createMuxLiveStream(stream.id);
      
      // Update stream with Mux details
      const updatedStream = await updateStreamWithMuxDetails(stream.id, {
        muxLiveStreamId: muxStream.id,
        muxStreamKey: muxStream.streamKey,
        muxPlaybackId: muxStream.playbackId,
        rtmpUrl: muxStream.rtmpUrl,
        hlsPlaybackUrl: getMuxPlaybackUrl(muxStream.playbackId),
      });

      const response: CreateStreamResponse = {
        stream: updatedStream,
        rtmpUrl: muxStream.rtmpUrl,
        rtmpKey: muxStream.streamKey,
      };

      return NextResponse.json(response, { status: 201 });
    } catch (muxError) {
      console.error('Error creating Mux stream:', muxError);
      // Stream created in DB but Mux failed - return stream anyway
      // DJ can retry or we can handle this in a background job
      return NextResponse.json(
        {
          stream,
          error: 'Stream created but streaming setup failed. Please try again.',
        },
        { status: 201 }
      );
    }
  } catch (error) {
    console.error('Error in POST /api/streams:', error);
    return NextResponse.json(
      { error: 'Failed to create stream' },
      { status: 500 }
    );
  }
}
