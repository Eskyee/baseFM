// app/api/streams/live/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getLiveStreams } from '@/lib/db/streams';
import { getListenerCount } from '@/lib/db/streams';

/**
 * GET /api/streams/live
 * Get all currently live streams with listener counts
 */
export async function GET(request: NextRequest) {
  try {
    const streams = await getLiveStreams();

    // Enrich with listener counts
    const streamsWithListeners = await Promise.all(
      streams.map(async (stream) => {
        const listenerCount = await getListenerCount(stream.id);
        return {
          ...stream,
          listenerCount,
        };
      })
    );

    return NextResponse.json({ streams: streamsWithListeners });
  } catch (error) {
    console.error('Error in GET /api/streams/live:', error);
    return NextResponse.json(
      { error: 'Failed to fetch live streams' },
      { status: 500 }
    );
  }
}
