// app/api/streams/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getStreamById, updateStream, deleteStream } from '@/lib/db/streams';
import { deleteMuxLiveStream } from '@/lib/streaming/mux';
import type { UpdateStreamRequest } from '@/types/stream';

/**
 * GET /api/streams/[id]
 * Get a single stream by ID
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const stream = await getStreamById(params.id);

    if (!stream) {
      return NextResponse.json(
        { error: 'Stream not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ stream });
  } catch (error) {
    console.error(`Error in GET /api/streams/${params.id}:`, error);
    return NextResponse.json(
      { error: 'Failed to fetch stream' },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/streams/[id]
 * Update stream metadata
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body: UpdateStreamRequest = await request.json();

    // Check if stream exists
    const existingStream = await getStreamById(params.id);
    if (!existingStream) {
      return NextResponse.json(
        { error: 'Stream not found' },
        { status: 404 }
      );
    }

    // TODO: Verify DJ ownership via wallet signature
    // For now, we allow updates (add auth in production)

    const updatedStream = await updateStream(params.id, body);

    return NextResponse.json({ stream: updatedStream });
  } catch (error) {
    console.error(`Error in PATCH /api/streams/${params.id}:`, error);
    return NextResponse.json(
      { error: 'Failed to update stream' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/streams/[id]
 * Delete a stream
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Check if stream exists
    const stream = await getStreamById(params.id);
    if (!stream) {
      return NextResponse.json(
        { error: 'Stream not found' },
        { status: 404 }
      );
    }

    // TODO: Verify DJ ownership via wallet signature
    // For now, we allow deletion (add auth in production)

    // Delete from Mux if it exists
    if (stream.muxLiveStreamId) {
      try {
        await deleteMuxLiveStream(stream.muxLiveStreamId);
      } catch (muxError) {
        console.error('Error deleting Mux stream:', muxError);
        // Continue with deletion even if Mux fails
      }
    }

    // Delete from database
    await deleteStream(params.id);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(`Error in DELETE /api/streams/${params.id}:`, error);
    return NextResponse.json(
      { error: 'Failed to delete stream' },
      { status: 500 }
    );
  }
}
