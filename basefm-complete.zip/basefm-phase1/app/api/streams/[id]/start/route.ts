// app/api/streams/[id]/start/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getStreamById, updateStreamStatus } from '@/lib/db/streams';
import type { StartStreamRequest, StartStreamResponse } from '@/types/stream';

/**
 * POST /api/streams/[id]/start
 * DJ signals they're ready to start broadcasting
 * Returns RTMP credentials for OBS/streaming software
 */
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body: StartStreamRequest = await request.json();

    // Validate request
    if (!body.djWalletAddress || !body.signature) {
      return NextResponse.json(
        { error: 'Missing djWalletAddress or signature' },
        { status: 400 }
      );
    }

    // Get stream
    const stream = await getStreamById(params.id);
    if (!stream) {
      return NextResponse.json(
        { error: 'Stream not found' },
        { status: 404 }
      );
    }

    // Verify DJ owns this stream
    if (stream.djWalletAddress.toLowerCase() !== body.djWalletAddress.toLowerCase()) {
      return NextResponse.json(
        { error: 'Unauthorized: You are not the DJ for this stream' },
        { status: 403 }
      );
    }

    // TODO: Verify wallet signature
    // const message = generateSignatureMessage(params.id, 'start_stream');
    // const isValid = await verifyDjOwnership(params.id, body.djWalletAddress, body.signature, message);
    // if (!isValid) {
    //   return NextResponse.json({ error: 'Invalid signature' }, { status: 403 });
    // }

    // Check stream is in valid state to start
    if (stream.status === 'LIVE') {
      return NextResponse.json(
        { error: 'Stream is already live' },
        { status: 400 }
      );
    }

    if (stream.status === 'ENDED') {
      return NextResponse.json(
        { error: 'Stream has already ended' },
        { status: 400 }
      );
    }

    // Verify Mux details exist
    if (!stream.rtmpUrl || !stream.muxStreamKey) {
      return NextResponse.json(
        { error: 'Stream not properly configured. Please recreate the stream.' },
        { status: 400 }
      );
    }

    // Update status to PREPARING (waiting for RTMP connection)
    const updatedStream = await updateStreamStatus(params.id, 'PREPARING');

    const response: StartStreamResponse = {
      stream: updatedStream,
      rtmpUrl: stream.rtmpUrl,
      rtmpKey: stream.muxStreamKey,
    };

    return NextResponse.json(response);
  } catch (error) {
    console.error(`Error in POST /api/streams/${params.id}/start:`, error);
    return NextResponse.json(
      { error: 'Failed to start stream' },
      { status: 500 }
    );
  }
}
