// app/api/streams/[id]/stop/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getStreamById, updateStreamStatus } from '@/lib/db/streams';

/**
 * POST /api/streams/[id]/stop
 * DJ stops their broadcast
 */
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();

    // Validate request
    if (!body.djWalletAddress) {
      return NextResponse.json(
        { error: 'Missing djWalletAddress' },
        { status: 400 }
      );
    }

    // Get stream
    const stream = await getStreamById(params.id);
    if (!stream) {
      return NextResponse.json(
        { error: 'Stream not found' },
        { status: 404 }
      );
    }

    // Verify DJ owns this stream
    if (stream.djWalletAddress.toLowerCase() !== body.djWalletAddress.toLowerCase()) {
      return NextResponse.json(
        { error: 'Unauthorized: You are not the DJ for this stream' },
        { status: 403 }
      );
    }

    // Check stream is in valid state to stop
    if (stream.status === 'ENDED') {
      return NextResponse.json(
        { error: 'Stream has already ended' },
        { status: 400 }
      );
    }

    if (stream.status === 'CREATED') {
      return NextResponse.json(
        { error: 'Stream was never started' },
        { status: 400 }
      );
    }

    // Update status to ENDING (grace period for HLS buffer)
    const updatedStream = await updateStreamStatus(params.id, 'ENDING');

    return NextResponse.json({ stream: updatedStream });
  } catch (error) {
    console.error(`Error in POST /api/streams/${params.id}/stop:`, error);
    return NextResponse.json(
      { error: 'Failed to stop stream' },
      { status: 500 }
    );
  }
}
