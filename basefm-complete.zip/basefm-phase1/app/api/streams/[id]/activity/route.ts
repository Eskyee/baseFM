// app/api/streams/[id]/activity/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { logStreamActivity } from '@/lib/db/streams';
import type { StreamActivityType } from '@/types/stream';

/**
 * POST /api/streams/[id]/activity
 * Log stream activity (listener joins, leaves, etc)
 */
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();

    // Validate request
    if (!body.eventType) {
      return NextResponse.json(
        { error: 'Missing eventType' },
        { status: 400 }
      );
    }

    const validEventTypes: StreamActivityType[] = [
      'CREATED',
      'STARTED',
      'ENDED',
      'LISTENER_JOINED',
      'LISTENER_LEFT',
    ];

    if (!validEventTypes.includes(body.eventType)) {
      return NextResponse.json(
        { error: 'Invalid eventType' },
        { status: 400 }
      );
    }

    // Log the activity
    await logStreamActivity({
      streamId: params.id,
      eventType: body.eventType,
      metadata: body.metadata || {},
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(`Error logging activity for stream ${params.id}:`, error);
    return NextResponse.json(
      { error: 'Failed to log activity' },
      { status: 500 }
    );
  }
}
