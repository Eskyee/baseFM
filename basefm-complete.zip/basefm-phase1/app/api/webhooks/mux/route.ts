// app/api/webhooks/mux/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { verifyMuxWebhookSignature, parseMuxWebhookEvent } from '@/lib/streaming/mux';
import { getStreamById, updateStreamStatus } from '@/lib/db/streams';

/**
 * POST /api/webhooks/mux
 * Handle Mux webhook events for stream status updates
 */
export async function POST(request: NextRequest) {
  try {
    // Get webhook signature from headers
    const signature = request.headers.get('mux-signature');
    if (!signature) {
      return NextResponse.json(
        { error: 'Missing Mux signature' },
        { status: 401 }
      );
    }

    // Get raw body for signature verification
    const body = await request.text();

    // Verify webhook signature
    const isValid = verifyMuxWebhookSignature(body, signature);
    if (!isValid) {
      console.error('Invalid Mux webhook signature');
      return NextResponse.json(
        { error: 'Invalid signature' },
        { status: 401 }
      );
    }

    // Parse webhook payload
    const payload = JSON.parse(body);
    const event = parseMuxWebhookEvent(payload);

    console.log('Received Mux webhook:', event.type, {
      liveStreamId: event.liveStreamId,
      baseFmStreamId: event.baseFmStreamId,
    });

    // Find our stream using the baseFmStreamId from passthrough
    if (!event.baseFmStreamId) {
      console.warn('No baseFmStreamId in webhook payload');
      return NextResponse.json({ received: true });
    }

    const stream = await getStreamById(event.baseFmStreamId);
    if (!stream) {
      console.error('Stream not found for webhook:', event.baseFmStreamId);
      return NextResponse.json({ received: true });
    }

    // Update stream status based on Mux event
    switch (event.type) {
      case 'stream_active':
        // DJ has connected and is broadcasting
        if (stream.status === 'PREPARING') {
          await updateStreamStatus(stream.id, 'LIVE');
          console.log(`Stream ${stream.id} is now LIVE`);
        }
        break;

      case 'stream_idle':
        // DJ disconnected but might reconnect (5min window)
        if (stream.status === 'LIVE') {
          await updateStreamStatus(stream.id, 'ENDING');
          console.log(`Stream ${stream.id} is now ENDING`);
        }
        break;

      case 'stream_disconnected':
        // DJ disconnected and reconnect window expired
        if (stream.status !== 'ENDED') {
          await updateStreamStatus(stream.id, 'ENDED');
          console.log(`Stream ${stream.id} has ENDED`);
        }
        break;

      case 'asset_created':
        // Recording is available (optional - for future use)
        console.log(`Recording created for stream ${stream.id}`);
        // TODO: Store recording URL in database
        break;

      default:
        console.log('Unhandled Mux event type:', event.type);
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error('Error processing Mux webhook:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Disable body parsing so we can verify the raw signature
export const config = {
  api: {
    bodyParser: false,
  },
};
