// app/stream/[id]/page.tsx
'use client';

import { useParams, useRouter } from 'next/navigation';
import { AudioPlayer } from '@/components/AudioPlayer';
import { TokenGate } from '@/components/TokenGate';
import { useStream } from '@/hooks/useStream';
import { useAccount } from 'wagmi';
import { useEffect, useState } from 'react';

export default function StreamPage() {
  const params = useParams();
  const router = useRouter();
  const { address, isConnected } = useAccount();
  const streamId = params.id as string;
  
  const { stream, isLive, isLoading, error } = useStream(streamId);
  const [hasLoggedActivity, setHasLoggedActivity] = useState(false);

  // Log listener joined when they visit the page
  useEffect(() => {
    if (!stream || hasLoggedActivity) return;

    const listenerId = generateListenerId();
    
    // Log listener joined
    fetch(`/api/streams/${stream.id}/activity`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        eventType: 'LISTENER_JOINED',
        metadata: { listenerId },
      }),
    }).catch(console.error);

    setHasLoggedActivity(true);

    // Log listener left on unmount
    return () => {
      fetch(`/api/streams/${stream.id}/activity`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          eventType: 'LISTENER_LEFT',
          metadata: { listenerId },
        }),
      }).catch(console.error);
    };
  }, [stream, hasLoggedActivity]);

  if (isLoading) {
    return (
      <div className="page-container">
        <div className="loading-container">
          <LoadingSpinner />
          <p>Loading stream...</p>
        </div>
      </div>
    );
  }

  if (error || !stream) {
    return (
      <div className="page-container">
        <div className="error-container">
          <h1>Stream Not Found</h1>
          <p>{error || 'This stream does not exist or has been removed.'}</p>
          <button onClick={() => router.push('/')} className="back-button">
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  // Check if stream is playable
  const canPlay = stream.status === 'LIVE' || stream.status === 'ENDING';
  const hlsUrl = stream.hlsPlaybackUrl;

  // Render player component
  const renderPlayer = () => {
    if (!canPlay || !hlsUrl) {
      return (
        <div className="not-live-message">
          <h2>This stream is not currently live</h2>
          <p>Status: {stream.status}</p>
          {stream.scheduledStartTime && (
            <p>
              Scheduled for:{' '}
              {new Date(stream.scheduledStartTime).toLocaleString()}
            </p>
          )}
        </div>
      );
    }

    return (
      <AudioPlayer
        streamUrl={hlsUrl}
        title={stream.title}
        djName={stream.djName}
        coverImage={stream.coverImageUrl}
        autoPlay={true}
        onPlay={() => console.log('Playing')}
        onPause={() => console.log('Paused')}
        onError={(err) => console.error('Playback error:', err)}
      />
    );
  };

  return (
    <div className="page-container">
      <div className="player-page">
        {/* Back Button */}
        <button onClick={() => router.push('/')} className="back-nav">
          ← Back
        </button>

        {/* Token Gating (if enabled) */}
        {stream.isGated && stream.requiredTokenAddress ? (
          <div className="gated-content">
            <div className="gated-badge">
              <span className="lock-icon">🔒</span>
              <span>Token Gated Stream</span>
            </div>

            <TokenGate
              tokenAddress={stream.requiredTokenAddress}
              requiredAmount={stream.requiredTokenAmount || 1}
              fallback={
                <div className="access-denied">
                  <p>This stream requires token ownership to access.</p>
                  {!isConnected && (
                    <p className="connect-hint">
                      Connect your wallet to check your balance.
                    </p>
                  )}
                </div>
              }
            >
              {/* Main Player */}
              <div className="player-section">
                {renderPlayer()}
              </div>
            </TokenGate>
          </div>
        ) : (
          /* Main Player (no gating) */
          <div className="player-section">
            {renderPlayer()}
          </div>
        )}

        {/* Stream Details */}
        <div className="details-section">
          <h1 className="stream-title">{stream.title}</h1>
          <p className="dj-name">by {stream.djName}</p>

          {stream.description && (
            <div className="description">
              <h3>About</h3>
              <p>{stream.description}</p>
            </div>
          )}

          {stream.genre && (
            <div className="genre">
              <span className="genre-tag">{stream.genre}</span>
            </div>
          )}

          {stream.tags && stream.tags.length > 0 && (
            <div className="tags">
              {stream.tags.map((tag) => (
                <span key={tag} className="tag">
                  {tag}
                </span>
              ))}
            </div>
          )}

          {/* Token Gating Info */}
          {stream.isGated && (
            <div className="gating-info">
              <h3>Access Requirements</h3>
              <div className="requirement">
                <span className="requirement-label">Required Token:</span>
                <span className="requirement-value monospace">
                  {stream.requiredTokenAddress?.slice(0, 6)}...
                  {stream.requiredTokenAddress?.slice(-4)}
                </span>
              </div>
              <div className="requirement">
                <span className="requirement-label">Minimum Balance:</span>
                <span className="requirement-value">
                  {stream.requiredTokenAmount || 1}
                </span>
              </div>
            </div>
          )}

          {/* Stream Status */}
          <div className="status-section">
            <h3>Status</h3>
            <div className="status-info">
              <StatusBadge status={stream.status} />
              {stream.actualStartTime && (
                <p className="time-info">
                  Started: {new Date(stream.actualStartTime).toLocaleString()}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .page-container {
          min-height: 100vh;
          background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
          padding: 24px;
        }

        .loading-container,
        .error-container {
          max-width: 600px;
          margin: 100px auto;
          text-align: center;
          color: #fff;
        }

        .error-container h1 {
          font-size: 32px;
          margin-bottom: 16px;
        }

        .error-container p {
          color: #a0a0a0;
          margin-bottom: 24px;
        }

        .back-button {
          padding: 12px 24px;
          background: #0052ff;
          color: #fff;
          border: none;
          border-radius: 8px;
          font-size: 16px;
          font-weight: 600;
          cursor: pointer;
          transition: opacity 0.2s ease;
        }

        .back-button:hover {
          opacity: 0.8;
        }

        .player-page {
          max-width: 800px;
          margin: 0 auto;
        }

        .back-nav {
          background: none;
          border: none;
          color: #a0a0a0;
          font-size: 16px;
          cursor: pointer;
          padding: 8px 0;
          margin-bottom: 24px;
          transition: color 0.2s ease;
        }

        .back-nav:hover {
          color: #fff;
        }

        .gated-content {
          margin-bottom: 48px;
        }

        .gated-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 8px 16px;
          background: rgba(255, 165, 0, 0.1);
          border: 1px solid #ffa500;
          border-radius: 20px;
          color: #ffa500;
          font-size: 14px;
          font-weight: 600;
          margin-bottom: 24px;
        }

        .lock-icon {
          font-size: 16px;
        }

        .access-denied {
          text-align: center;
          padding: 24px;
          color: #a0a0a0;
        }

        .connect-hint {
          color: #0052ff;
          margin-top: 12px;
        }

        .player-section {
          margin-bottom: 48px;
        }

        .not-live-message {
          background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
          border-radius: 16px;
          padding: 48px;
          text-align: center;
          color: #fff;
        }

        .not-live-message h2 {
          font-size: 24px;
          margin-bottom: 16px;
        }

        .not-live-message p {
          color: #a0a0a0;
          margin-bottom: 8px;
        }

        .details-section {
          color: #fff;
        }

        .stream-title {
          font-size: 36px;
          font-weight: 700;
          margin: 0 0 12px 0;
        }

        .dj-name {
          font-size: 20px;
          color: #a0a0a0;
          margin: 0 0 32px 0;
        }

        .description {
          margin-bottom: 32px;
        }

        .description h3 {
          font-size: 18px;
          margin-bottom: 12px;
        }

        .description p {
          color: #a0a0a0;
          line-height: 1.6;
        }

        .genre {
          margin-bottom: 24px;
        }

        .genre-tag {
          display: inline-block;
          padding: 8px 16px;
          background: rgba(0, 82, 255, 0.2);
          color: #0052ff;
          border-radius: 20px;
          font-size: 14px;
          font-weight: 600;
        }

        .tags {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          margin-bottom: 32px;
        }

        .tag {
          padding: 6px 12px;
          background: #2d2d2d;
          color: #a0a0a0;
          border-radius: 16px;
          font-size: 14px;
        }

        .gating-info {
          margin-bottom: 32px;
          padding: 24px;
          background: rgba(255, 165, 0, 0.05);
          border: 1px solid rgba(255, 165, 0, 0.2);
          border-radius: 12px;
        }

        .gating-info h3 {
          font-size: 18px;
          margin-bottom: 16px;
          color: #ffa500;
        }

        .requirement {
          display: flex;
          justify-content: space-between;
          padding: 12px 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .requirement:last-child {
          border-bottom: none;
        }

        .requirement-label {
          color: #a0a0a0;
          font-size: 14px;
        }

        .requirement-value {
          color: #fff;
          font-size: 14px;
          font-weight: 600;
        }

        .monospace {
          font-family: monospace;
        }

        .status-section h3 {
          font-size: 18px;
          margin-bottom: 16px;
        }

        .status-info {
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .time-info {
          color: #a0a0a0;
          font-size: 14px;
          margin: 0;
        }
      `}</style>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const colors = {
    LIVE: '#00ff00',
    PREPARING: '#ffaa00',
    ENDING: '#ff6600',
    ENDED: '#666666',
    CREATED: '#0052ff',
  };

  return (
    <span
      className="status-badge"
      style={{ background: colors[status as keyof typeof colors] || '#666' }}
    >
      {status}
      <style jsx>{`
        .status-badge {
          padding: 8px 16px;
          border-radius: 20px;
          color: #000;
          font-size: 14px;
          font-weight: 700;
          letter-spacing: 0.5px;
        }
      `}</style>
    </span>
  );
}

function LoadingSpinner() {
  return (
    <div className="spinner">
      <style jsx>{`
        .spinner {
          width: 48px;
          height: 48px;
          border: 4px solid #333;
          border-top-color: #0052ff;
          border-radius: 50%;
          animation: spin 1s linear infinite;
          margin: 0 auto 16px;
        }

        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }
      `}</style>
    </div>
  );
}

function generateListenerId(): string {
  return `listener_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}
