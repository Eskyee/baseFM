// app/page.tsx
'use client';

import { StreamCard } from '@/components/StreamCard';
import { useLiveStreams, useStreams } from '@/hooks/useStreams';

export default function HomePage() {
  const { streams: liveStreams, isLoading: liveLoading } = useLiveStreams();
  const {
    streams: upcomingStreams,
    isLoading: upcomingLoading,
  } = useStreams({
    status: 'CREATED',
    limit: 6,
  });

  return (
    <div className="home-page">
      {/* Hero Section */}
      <div className="hero">
        <h1 className="hero-title">baseFM</h1>
        <p className="hero-subtitle">Onchain Radio. Live Now.</p>
      </div>

      {/* Live Streams Section */}
      <section className="streams-section">
        <div className="section-header">
          <h2>Live Now</h2>
          <span className="live-indicator">
            <span className="live-dot"></span>
            {liveStreams.length} LIVE
          </span>
        </div>

        {liveLoading ? (
          <div className="loading-grid">
            <LoadingCard />
            <LoadingCard />
            <LoadingCard />
          </div>
        ) : liveStreams.length === 0 ? (
          <div className="empty-state">
            <p>No live streams right now</p>
            <p className="empty-subtitle">Check back soon for live broadcasts</p>
          </div>
        ) : (
          <div className="streams-grid">
            {liveStreams.map((stream) => (
              <StreamCard
                key={stream.id}
                stream={stream}
                listenerCount={(stream as any).listenerCount}
              />
            ))}
          </div>
        )}
      </section>

      {/* Upcoming Streams Section */}
      {upcomingStreams.length > 0 && (
        <section className="streams-section">
          <div className="section-header">
            <h2>Coming Up</h2>
          </div>

          {upcomingLoading ? (
            <div className="loading-grid">
              <LoadingCard />
              <LoadingCard />
            </div>
          ) : (
            <div className="streams-grid">
              {upcomingStreams.map((stream) => (
                <StreamCard key={stream.id} stream={stream} />
              ))}
            </div>
          )}
        </section>
      )}

      <style jsx>{`
        .home-page {
          min-height: 100vh;
          background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
          padding: 48px 24px;
        }

        .hero {
          max-width: 1200px;
          margin: 0 auto 64px;
          text-align: center;
        }

        .hero-title {
          font-size: 72px;
          font-weight: 900;
          background: linear-gradient(135deg, #0052ff 0%, #00ffff 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          margin: 0 0 16px 0;
          letter-spacing: -2px;
        }

        .hero-subtitle {
          font-size: 24px;
          color: #a0a0a0;
          margin: 0;
        }

        .streams-section {
          max-width: 1200px;
          margin: 0 auto 64px;
        }

        .section-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 24px;
        }

        .section-header h2 {
          color: #fff;
          font-size: 32px;
          font-weight: 700;
          margin: 0;
        }

        .live-indicator {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 16px;
          background: rgba(255, 0, 0, 0.1);
          border-radius: 20px;
          color: #ff0000;
          font-size: 14px;
          font-weight: 700;
          letter-spacing: 0.5px;
        }

        .live-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #ff0000;
          animation: pulse 2s ease-in-out infinite;
        }

        .streams-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
          gap: 24px;
        }

        .loading-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
          gap: 24px;
        }

        .empty-state {
          background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
          border-radius: 16px;
          padding: 64px;
          text-align: center;
          color: #fff;
        }

        .empty-state p {
          font-size: 20px;
          margin: 0 0 8px 0;
        }

        .empty-subtitle {
          color: #a0a0a0;
          font-size: 16px;
        }

        @keyframes pulse {
          0%,
          100% {
            opacity: 1;
            transform: scale(1);
          }
          50% {
            opacity: 0.6;
            transform: scale(1.2);
          }
        }

        @media (max-width: 768px) {
          .home-page {
            padding: 32px 16px;
          }

          .hero-title {
            font-size: 48px;
          }

          .hero-subtitle {
            font-size: 18px;
          }

          .streams-grid {
            grid-template-columns: 1fr;
          }

          .section-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 12px;
          }
        }
      `}</style>
    </div>
  );
}

function LoadingCard() {
  return (
    <div className="loading-card">
      <div className="loading-image"></div>
      <div className="loading-content">
        <div className="loading-line long"></div>
        <div className="loading-line short"></div>
      </div>

      <style jsx>{`
        .loading-card {
          background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
          border-radius: 16px;
          overflow: hidden;
        }

        .loading-image {
          width: 100%;
          aspect-ratio: 1;
          background: linear-gradient(90deg, #2d2d2d 0%, #3d3d3d 50%, #2d2d2d 100%);
          background-size: 200% 100%;
          animation: shimmer 1.5s infinite;
        }

        .loading-content {
          padding: 16px;
        }

        .loading-line {
          height: 16px;
          border-radius: 8px;
          background: linear-gradient(90deg, #2d2d2d 0%, #3d3d3d 50%, #2d2d2d 100%);
          background-size: 200% 100%;
          animation: shimmer 1.5s infinite;
          margin-bottom: 8px;
        }

        .loading-line.long {
          width: 80%;
        }

        .loading-line.short {
          width: 50%;
        }

        @keyframes shimmer {
          0% {
            background-position: 200% 0;
          }
          100% {
            background-position: -200% 0;
          }
        }
      `}</style>
    </div>
  );
}
