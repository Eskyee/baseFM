// app/dj/page.tsx
'use client';

import { useState } from 'react';
import { useAccount } from 'wagmi';
import { useStreams } from '@/hooks/useStreams';
import { StreamCard } from '@/components/StreamCard';
import Link from 'next/link';

export default function DJDashboardPage() {
  const { address, isConnected } = useAccount();
  const [activeTab, setActiveTab] = useState<'my-streams' | 'create'>('my-streams');

  // Fetch DJ's streams
  const { streams, isLoading } = useStreams({
    djWalletAddress: address?.toLowerCase(),
  });

  if (!isConnected) {
    return (
      <div className="page-container">
        <div className="connect-prompt">
          <h1>Connect Your Wallet</h1>
          <p>Connect your wallet to access the DJ dashboard and create streams.</p>
          <div className="connect-illustration">
            <WalletIcon />
          </div>
        </div>
      </div>
    );
  }

  const liveStreams = streams.filter((s) => s.status === 'LIVE');
  const upcomingStreams = streams.filter((s) => s.status === 'CREATED' || s.status === 'PREPARING');
  const pastStreams = streams.filter((s) => s.status === 'ENDED');

  return (
    <div className="page-container">
      <div className="dashboard">
        {/* Header */}
        <div className="dashboard-header">
          <div>
            <h1>DJ Dashboard</h1>
            <p className="wallet-address">
              {address?.slice(0, 6)}...{address?.slice(-4)}
            </p>
          </div>
          <Link href="/dj/create" className="create-button">
            + Create Stream
          </Link>
        </div>

        {/* Stats */}
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-value">{liveStreams.length}</div>
            <div className="stat-label">Live Now</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{upcomingStreams.length}</div>
            <div className="stat-label">Upcoming</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{streams.length}</div>
            <div className="stat-label">Total Streams</div>
          </div>
        </div>

        {/* Live Streams */}
        {liveStreams.length > 0 && (
          <section className="streams-section">
            <h2>Currently Live</h2>
            <div className="streams-grid">
              {liveStreams.map((stream) => (
                <DJStreamCard key={stream.id} stream={stream} />
              ))}
            </div>
          </section>
        )}

        {/* Upcoming Streams */}
        {upcomingStreams.length > 0 && (
          <section className="streams-section">
            <h2>Upcoming</h2>
            <div className="streams-grid">
              {upcomingStreams.map((stream) => (
                <DJStreamCard key={stream.id} stream={stream} />
              ))}
            </div>
          </section>
        )}

        {/* Past Streams */}
        {pastStreams.length > 0 && (
          <section className="streams-section">
            <h2>Past Streams</h2>
            <div className="streams-grid">
              {pastStreams.map((stream) => (
                <DJStreamCard key={stream.id} stream={stream} />
              ))}
            </div>
          </section>
        )}

        {/* Empty State */}
        {streams.length === 0 && !isLoading && (
          <div className="empty-state">
            <h3>No streams yet</h3>
            <p>Create your first stream to get started</p>
            <Link href="/dj/create" className="create-button-large">
              Create Your First Stream
            </Link>
          </div>
        )}
      </div>

      <style jsx>{`
        .page-container {
          min-height: 100vh;
          background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
          padding: 48px 24px;
        }

        .connect-prompt {
          max-width: 600px;
          margin: 100px auto;
          text-align: center;
          color: #fff;
        }

        .connect-prompt h1 {
          font-size: 48px;
          margin-bottom: 16px;
        }

        .connect-prompt p {
          font-size: 18px;
          color: #a0a0a0;
          margin-bottom: 48px;
        }

        .connect-illustration {
          width: 120px;
          height: 120px;
          margin: 0 auto;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
          border-radius: 24px;
        }

        .dashboard {
          max-width: 1400px;
          margin: 0 auto;
        }

        .dashboard-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 32px;
        }

        .dashboard-header h1 {
          color: #fff;
          font-size: 48px;
          font-weight: 900;
          margin: 0 0 8px 0;
        }

        .wallet-address {
          color: #a0a0a0;
          font-size: 16px;
          font-family: monospace;
        }

        .create-button {
          padding: 16px 32px;
          background: linear-gradient(135deg, #0052ff 0%, #0040cc 100%);
          color: #fff;
          border: none;
          border-radius: 12px;
          font-size: 16px;
          font-weight: 700;
          cursor: pointer;
          transition: transform 0.2s ease, box-shadow 0.2s ease;
          text-decoration: none;
          display: inline-block;
        }

        .create-button:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(0, 82, 255, 0.4);
        }

        .create-button-large {
          padding: 20px 40px;
          background: linear-gradient(135deg, #0052ff 0%, #0040cc 100%);
          color: #fff;
          border: none;
          border-radius: 12px;
          font-size: 18px;
          font-weight: 700;
          cursor: pointer;
          transition: transform 0.2s ease, box-shadow 0.2s ease;
          text-decoration: none;
          display: inline-block;
          margin-top: 24px;
        }

        .create-button-large:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(0, 82, 255, 0.4);
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 24px;
          margin-bottom: 48px;
        }

        .stat-card {
          background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
          border-radius: 16px;
          padding: 32px;
          text-align: center;
        }

        .stat-value {
          font-size: 48px;
          font-weight: 900;
          color: #0052ff;
          margin-bottom: 8px;
        }

        .stat-label {
          font-size: 16px;
          color: #a0a0a0;
          font-weight: 600;
        }

        .streams-section {
          margin-bottom: 48px;
        }

        .streams-section h2 {
          color: #fff;
          font-size: 32px;
          font-weight: 700;
          margin-bottom: 24px;
        }

        .streams-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
          gap: 24px;
        }

        .empty-state {
          background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
          border-radius: 16px;
          padding: 80px;
          text-align: center;
          color: #fff;
        }

        .empty-state h3 {
          font-size: 32px;
          margin-bottom: 16px;
        }

        .empty-state p {
          font-size: 18px;
          color: #a0a0a0;
        }

        @media (max-width: 768px) {
          .page-container {
            padding: 24px 16px;
          }

          .dashboard-header {
            flex-direction: column;
            gap: 24px;
          }

          .dashboard-header h1 {
            font-size: 36px;
          }

          .stats-grid {
            grid-template-columns: 1fr;
          }

          .streams-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
}

// DJ-specific stream card with manage button
function DJStreamCard({ stream }: { stream: any }) {
  return (
    <div className="dj-stream-card">
      <StreamCard stream={stream} />
      <div className="card-actions">
        <Link href={`/dj/stream/${stream.id}`} className="manage-button">
          Manage
        </Link>
      </div>

      <style jsx>{`
        .dj-stream-card {
          position: relative;
        }

        .card-actions {
          margin-top: 12px;
        }

        .manage-button {
          display: block;
          width: 100%;
          padding: 12px;
          background: rgba(0, 82, 255, 0.1);
          color: #0052ff;
          border: 1px solid #0052ff;
          border-radius: 8px;
          text-align: center;
          font-weight: 600;
          text-decoration: none;
          transition: background 0.2s ease;
        }

        .manage-button:hover {
          background: rgba(0, 82, 255, 0.2);
        }
      `}</style>
    </div>
  );
}

function WalletIcon() {
  return (
    <svg width="64" height="64" viewBox="0 0 24 24" fill="none">
      <path
        d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"
        fill="#0052ff"
      />
    </svg>
  );
}
