// app/dj/stream/[id]/page.tsx
'use client';

import { useParams, useRouter } from 'next/navigation';
import { useAccount } from 'wagmi';
import { useStream } from '@/hooks/useStream';
import { useState } from 'react';
import { getListenerCount } from '@/lib/db/streams';

export default function ManageStreamPage() {
  const params = useParams();
  const router = useRouter();
  const { address, isConnected } = useAccount();
  const streamId = params.id as string;

  const { stream, isLoading, error, refetch } = useStream(streamId);
  const [isStarting, setIsStarting] = useState(false);
  const [isStopping, setIsStopping] = useState(false);
  const [showCredentials, setShowCredentials] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  // Check if user is the DJ
  const isDJ = isConnected && address && stream?.djWalletAddress.toLowerCase() === address.toLowerCase();

  const handleStartStream = async () => {
    if (!stream || !address) return;

    setIsStarting(true);
    setActionError(null);

    try {
      const response = await fetch(`/api/streams/${stream.id}/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          djWalletAddress: address.toLowerCase(),
          signature: '0x0', // TODO: Implement real signature
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to start stream');
      }

      // Show credentials modal
      setShowCredentials(true);
      await refetch();
    } catch (err) {
      console.error('Error starting stream:', err);
      setActionError(err instanceof Error ? err.message : 'Failed to start stream');
    } finally {
      setIsStarting(false);
    }
  };

  const handleStopStream = async () => {
    if (!stream || !address) return;

    if (!confirm('Are you sure you want to stop this stream?')) {
      return;
    }

    setIsStopping(true);
    setActionError(null);

    try {
      const response = await fetch(`/api/streams/${stream.id}/stop`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          djWalletAddress: address.toLowerCase(),
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to stop stream');
      }

      await refetch();
    } catch (err) {
      console.error('Error stopping stream:', err);
      setActionError(err instanceof Error ? err.message : 'Failed to stop stream');
    } finally {
      setIsStopping(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copied to clipboard!');
  };

  if (isLoading) {
    return (
      <div className="page-container">
        <div className="loading">Loading stream...</div>
      </div>
    );
  }

  if (error || !stream) {
    return (
      <div className="page-container">
        <div className="error-container">
          <h1>Stream Not Found</h1>
          <button onClick={() => router.push('/dj')} className="back-button">
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  if (!isDJ) {
    return (
      <div className="page-container">
        <div className="error-container">
          <h1>Unauthorized</h1>
          <p>You are not the owner of this stream.</p>
          <button onClick={() => router.push('/dj')} className="back-button">
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const canStart = stream.status === 'CREATED' || stream.status === 'PREPARING';
  const canStop = stream.status === 'LIVE' || stream.status === 'PREPARING';
  const isLive = stream.status === 'LIVE';
  const isPreparing = stream.status === 'PREPARING';

  return (
    <div className="page-container">
      <div className="manage-container">
        {/* Header */}
        <div className="header">
          <button onClick={() => router.push('/dj')} className="back-link">
            ← Back to Dashboard
          </button>
          <h1>{stream.title}</h1>
          <StatusBadge status={stream.status} />
        </div>

        {/* Main Controls */}
        <div className="controls-grid">
          {/* Status Card */}
          <div className="card">
            <h2>Stream Status</h2>
            <div className="status-display">
              <div className="status-indicator" style={{ background: getStatusColor(stream.status) }} />
              <div>
                <div className="status-text">{stream.status}</div>
                {isLive && <div className="status-subtext">Broadcasting live</div>}
                {isPreparing && <div className="status-subtext">Waiting for RTMP connection</div>}
              </div>
            </div>

            {isLive && (
              <div className="live-stats">
                <div className="stat">
                  <div className="stat-label">Listeners</div>
                  <div className="stat-value">0</div>
                </div>
                <div className="stat">
                  <div className="stat-label">Duration</div>
                  <div className="stat-value">
                    {stream.actualStartTime
                      ? formatDuration(new Date(stream.actualStartTime))
                      : '00:00'}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Actions Card */}
          <div className="card">
            <h2>Quick Actions</h2>

            {canStart && (
              <button
                onClick={handleStartStream}
                disabled={isStarting}
                className="action-button primary"
              >
                {isStarting ? 'Starting...' : 'Start Stream'}
              </button>
            )}

            {canStop && (
              <button
                onClick={handleStopStream}
                disabled={isStopping}
                className="action-button danger"
              >
                {isStopping ? 'Stopping...' : 'Stop Stream'}
              </button>
            )}

            {(stream.status === 'PREPARING' || stream.status === 'LIVE') && (
              <button
                onClick={() => setShowCredentials(true)}
                className="action-button secondary"
              >
                View RTMP Credentials
              </button>
            )}

            <button
              onClick={() => window.open(`/stream/${stream.id}`, '_blank')}
              className="action-button secondary"
              >
                Open Player Page
              </button>

            {actionError && (
              <div className="error-message">{actionError}</div>
            )}
          </div>
        </div>

        {/* Stream Details */}
        <div className="card">
          <h2>Stream Details</h2>
          <div className="details-grid">
            <div className="detail-item">
              <div className="detail-label">Stream ID</div>
              <div className="detail-value monospace">{stream.id}</div>
            </div>
            <div className="detail-item">
              <div className="detail-label">DJ Name</div>
              <div className="detail-value">{stream.djName}</div>
            </div>
            {stream.genre && (
              <div className="detail-item">
                <div className="detail-label">Genre</div>
                <div className="detail-value">{stream.genre}</div>
              </div>
            )}
            {stream.scheduledStartTime && (
              <div className="detail-item">
                <div className="detail-label">Scheduled Start</div>
                <div className="detail-value">
                  {new Date(stream.scheduledStartTime).toLocaleString()}
                </div>
              </div>
            )}
            {stream.actualStartTime && (
              <div className="detail-item">
                <div className="detail-label">Actual Start</div>
                <div className="detail-value">
                  {new Date(stream.actualStartTime).toLocaleString()}
                </div>
              </div>
            )}
            {stream.isGated && (
              <div className="detail-item">
                <div className="detail-label">Token Gating</div>
                <div className="detail-value">Enabled</div>
              </div>
            )}
          </div>
        </div>

        {/* RTMP Credentials Modal */}
        {showCredentials && stream.rtmpUrl && stream.muxStreamKey && (
          <div className="modal-overlay" onClick={() => setShowCredentials(false)}>
            <div className="modal" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h2>RTMP Streaming Credentials</h2>
                <button onClick={() => setShowCredentials(false)} className="close-button">
                  ×
                </button>
              </div>

              <div className="credentials">
                <div className="credential-item">
                  <label>RTMP Server URL</label>
                  <div className="credential-value">
                    <code>{stream.rtmpUrl}</code>
                    <button onClick={() => copyToClipboard(stream.rtmpUrl!)} className="copy-button">
                      Copy
                    </button>
                  </div>
                </div>

                <div className="credential-item">
                  <label>Stream Key</label>
                  <div className="credential-value">
                    <code>{stream.muxStreamKey}</code>
                    <button onClick={() => copyToClipboard(stream.muxStreamKey!)} className="copy-button">
                      Copy
                    </button>
                  </div>
                </div>
              </div>

              <div className="modal-instructions">
                <h3>Setup Instructions (OBS)</h3>
                <ol>
                  <li>Open OBS Studio</li>
                  <li>Go to Settings → Stream</li>
                  <li>Service: Custom</li>
                  <li>Server: Paste the RTMP URL above</li>
                  <li>Stream Key: Paste the stream key above</li>
                  <li>Click "Start Streaming" in OBS</li>
                  <li>Your stream will go LIVE automatically</li>
                </ol>
              </div>
            </div>
          </div>
        )}
      </div>

      <style jsx>{`
        .page-container {
          min-height: 100vh;
          background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
          padding: 48px 24px;
        }

        .loading,
        .error-container {
          max-width: 600px;
          margin: 100px auto;
          text-align: center;
          color: #fff;
        }

        .manage-container {
          max-width: 1200px;
          margin: 0 auto;
        }

        .header {
          margin-bottom: 32px;
        }

        .back-link {
          background: none;
          border: none;
          color: #a0a0a0;
          font-size: 16px;
          cursor: pointer;
          padding: 8px 0;
          margin-bottom: 16px;
          display: block;
        }

        .back-link:hover {
          color: #fff;
        }

        .header h1 {
          color: #fff;
          font-size: 48px;
          font-weight: 900;
          margin: 0 0 16px 0;
        }

        .controls-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 24px;
          margin-bottom: 24px;
        }

        .card {
          background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
          border-radius: 16px;
          padding: 32px;
        }

        .card h2 {
          color: #fff;
          font-size: 24px;
          font-weight: 700;
          margin: 0 0 24px 0;
        }

        .status-display {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 24px;
          background: rgba(0, 0, 0, 0.3);
          border-radius: 12px;
          margin-bottom: 24px;
        }

        .status-indicator {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          animation: pulse 2s ease-in-out infinite;
        }

        .status-text {
          color: #fff;
          font-size: 20px;
          font-weight: 700;
        }

        .status-subtext {
          color: #a0a0a0;
          font-size: 14px;
        }

        .live-stats {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
        }

        .stat {
          padding: 16px;
          background: rgba(0, 0, 0, 0.3);
          border-radius: 12px;
          text-align: center;
        }

        .stat-label {
          color: #a0a0a0;
          font-size: 12px;
          margin-bottom: 8px;
        }

        .stat-value {
          color: #fff;
          font-size: 32px;
          font-weight: 700;
        }

        .action-button {
          width: 100%;
          padding: 16px;
          border: none;
          border-radius: 12px;
          font-size: 16px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s ease;
          margin-bottom: 12px;
        }

        .action-button.primary {
          background: linear-gradient(135deg, #00ff00 0%, #00cc00 100%);
          color: #000;
        }

        .action-button.primary:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(0, 255, 0, 0.4);
        }

        .action-button.danger {
          background: linear-gradient(135deg, #ff0000 0%, #cc0000 100%);
          color: #fff;
        }

        .action-button.danger:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(255, 0, 0, 0.4);
        }

        .action-button.secondary {
          background: rgba(0, 82, 255, 0.1);
          border: 1px solid #0052ff;
          color: #0052ff;
        }

        .action-button.secondary:hover:not(:disabled) {
          background: rgba(0, 82, 255, 0.2);
        }

        .action-button:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .error-message {
          background: rgba(255, 0, 0, 0.1);
          border: 1px solid #ff0000;
          border-radius: 8px;
          padding: 12px;
          color: #ff4444;
          font-size: 14px;
        }

        .details-grid {
          display: grid;
          gap: 16px;
        }

        .detail-item {
          padding: 16px;
          background: rgba(0, 0, 0, 0.3);
          border-radius: 12px;
        }

        .detail-label {
          color: #a0a0a0;
          font-size: 12px;
          margin-bottom: 4px;
        }

        .detail-value {
          color: #fff;
          font-size: 16px;
          font-weight: 600;
        }

        .detail-value.monospace {
          font-family: monospace;
          font-size: 14px;
        }

        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.8);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
        }

        .modal {
          background: #1a1a1a;
          border-radius: 16px;
          max-width: 600px;
          width: 90%;
          max-height: 90vh;
          overflow-y: auto;
        }

        .modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 24px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .modal-header h2 {
          color: #fff;
          font-size: 24px;
          margin: 0;
        }

        .close-button {
          background: none;
          border: none;
          color: #fff;
          font-size: 32px;
          cursor: pointer;
          padding: 0;
          width: 32px;
          height: 32px;
          line-height: 1;
        }

        .credentials {
          padding: 24px;
        }

        .credential-item {
          margin-bottom: 24px;
        }

        .credential-item label {
          display: block;
          color: #a0a0a0;
          font-size: 14px;
          margin-bottom: 8px;
        }

        .credential-value {
          display: flex;
          gap: 8px;
        }

        .credential-value code {
          flex: 1;
          padding: 12px;
          background: rgba(0, 0, 0, 0.5);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          color: #fff;
          font-family: monospace;
          font-size: 14px;
          word-break: break-all;
        }

        .copy-button {
          padding: 12px 24px;
          background: #0052ff;
          color: #fff;
          border: none;
          border-radius: 8px;
          font-weight: 600;
          cursor: pointer;
          white-space: nowrap;
        }

        .modal-instructions {
          padding: 0 24px 24px;
          color: #fff;
        }

        .modal-instructions h3 {
          font-size: 18px;
          margin-bottom: 16px;
        }

        .modal-instructions ol {
          padding-left: 24px;
          color: #a0a0a0;
          line-height: 1.8;
        }

        @keyframes pulse {
          0%, 100% {
            opacity: 1;
          }
          50% {
            opacity: 0.6;
          }
        }

        @media (max-width: 768px) {
          .controls-grid {
            grid-template-columns: 1fr;
          }

          .modal {
            width: 95%;
          }
        }
      `}</style>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  return (
    <span className="status-badge" style={{ background: getStatusColor(status) }}>
      {status}
      <style jsx>{`
        .status-badge {
          display: inline-block;
          padding: 8px 16px;
          border-radius: 20px;
          color: #000;
          font-size: 14px;
          font-weight: 700;
          letter-spacing: 0.5px;
        }
      `}</style>
    </span>
  );
}

function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    LIVE: '#00ff00',
    PREPARING: '#ffaa00',
    ENDING: '#ff6600',
    ENDED: '#666666',
    CREATED: '#0052ff',
  };
  return colors[status] || '#666666';
}

function formatDuration(startTime: Date): string {
  const now = new Date();
  const diff = now.getTime() - startTime.getTime();
  const minutes = Math.floor(diff / 60000);
  const seconds = Math.floor((diff % 60000) / 1000);
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}
