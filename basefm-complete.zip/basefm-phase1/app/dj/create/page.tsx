// app/dj/create/page.tsx
'use client';

import { useState, FormEvent } from 'react';
import { useAccount } from 'wagmi';
import { useRouter } from 'next/navigation';

export default function CreateStreamPage() {
  const { address, isConnected } = useAccount();
  const router = useRouter();

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    djName: '',
    genre: '',
    tags: '',
    coverImageUrl: '',
    scheduledStartTime: '',
    isGated: false,
    requiredTokenAddress: '',
    requiredTokenAmount: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!isConnected || !address) {
      setError('Please connect your wallet');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const response = await fetch('/api/streams', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: formData.title,
          description: formData.description || undefined,
          djName: formData.djName,
          djWalletAddress: address.toLowerCase(),
          genre: formData.genre || undefined,
          tags: formData.tags ? formData.tags.split(',').map((t) => t.trim()) : undefined,
          coverImageUrl: formData.coverImageUrl || undefined,
          scheduledStartTime: formData.scheduledStartTime || undefined,
          isGated: formData.isGated,
          requiredTokenAddress: formData.isGated ? formData.requiredTokenAddress : undefined,
          requiredTokenAmount: formData.isGated ? parseFloat(formData.requiredTokenAmount) : undefined,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to create stream');
      }

      const data = await response.json();
      
      // Redirect to stream management page
      router.push(`/dj/stream/${data.stream.id}`);
    } catch (err) {
      console.error('Error creating stream:', err);
      setError(err instanceof Error ? err.message : 'Failed to create stream');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isConnected) {
    return (
      <div className="page-container">
        <div className="connect-prompt">
          <h1>Connect Your Wallet</h1>
          <p>Please connect your wallet to create a stream.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="create-form-container">
        <div className="form-header">
          <h1>Create New Stream</h1>
          <p>Set up your live stream details</p>
        </div>

        <form onSubmit={handleSubmit} className="create-form">
          {/* Basic Info */}
          <div className="form-section">
            <h2>Basic Information</h2>
            
            <div className="form-group">
              <label htmlFor="title">Stream Title *</label>
              <input
                id="title"
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Friday Night Vibes"
                maxLength={100}
              />
            </div>

            <div className="form-group">
              <label htmlFor="djName">DJ Name *</label>
              <input
                id="djName"
                type="text"
                required
                value={formData.djName}
                onChange={(e) => setFormData({ ...formData, djName: e.target.value })}
                placeholder="DJ Alpha"
                maxLength={50}
              />
            </div>

            <div className="form-group">
              <label htmlFor="description">Description</label>
              <textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Tell listeners what to expect..."
                rows={4}
                maxLength={500}
              />
            </div>
          </div>

          {/* Metadata */}
          <div className="form-section">
            <h2>Metadata</h2>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="genre">Genre</label>
                <input
                  id="genre"
                  type="text"
                  value={formData.genre}
                  onChange={(e) => setFormData({ ...formData, genre: e.target.value })}
                  placeholder="House, Techno, Hip Hop..."
                  maxLength={30}
                />
              </div>

              <div className="form-group">
                <label htmlFor="tags">Tags (comma-separated)</label>
                <input
                  id="tags"
                  type="text"
                  value={formData.tags}
                  onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                  placeholder="electronic, live, party"
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="coverImageUrl">Cover Image URL</label>
              <input
                id="coverImageUrl"
                type="url"
                value={formData.coverImageUrl}
                onChange={(e) => setFormData({ ...formData, coverImageUrl: e.target.value })}
                placeholder="https://example.com/image.jpg"
              />
              <small>Use a square image (1:1 ratio) for best results</small>
            </div>
          </div>

          {/* Scheduling */}
          <div className="form-section">
            <h2>Schedule (Optional)</h2>

            <div className="form-group">
              <label htmlFor="scheduledStartTime">Scheduled Start Time</label>
              <input
                id="scheduledStartTime"
                type="datetime-local"
                value={formData.scheduledStartTime}
                onChange={(e) => setFormData({ ...formData, scheduledStartTime: e.target.value })}
              />
              <small>Leave empty for immediate streaming</small>
            </div>
          </div>

          {/* Token Gating */}
          <div className="form-section">
            <h2>Token Gating (Optional)</h2>

            <div className="form-group">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={formData.isGated}
                  onChange={(e) => setFormData({ ...formData, isGated: e.target.checked })}
                />
                <span>Require token to listen</span>
              </label>
            </div>

            {formData.isGated && (
              <>
                <div className="form-group">
                  <label htmlFor="requiredTokenAddress">Token Address</label>
                  <input
                    id="requiredTokenAddress"
                    type="text"
                    value={formData.requiredTokenAddress}
                    onChange={(e) => setFormData({ ...formData, requiredTokenAddress: e.target.value })}
                    placeholder="0x..."
                    pattern="^0x[a-fA-F0-9]{40}$"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="requiredTokenAmount">Minimum Token Balance</label>
                  <input
                    id="requiredTokenAmount"
                    type="number"
                    step="0.000001"
                    min="0"
                    value={formData.requiredTokenAmount}
                    onChange={(e) => setFormData({ ...formData, requiredTokenAmount: e.target.value })}
                    placeholder="1.0"
                  />
                </div>
              </>
            )}
          </div>

          {/* Error Message */}
          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          {/* Submit */}
          <div className="form-actions">
            <button
              type="button"
              onClick={() => router.back()}
              className="cancel-button"
              disabled={isSubmitting}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="submit-button"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Creating...' : 'Create Stream'}
            </button>
          </div>
        </form>
      </div>

      <style jsx>{`
        .page-container {
          min-height: 100vh;
          background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
          padding: 48px 24px;
        }

        .connect-prompt {
          max-width: 600px;
          margin: 100px auto;
          text-align: center;
          color: #fff;
        }

        .connect-prompt h1 {
          font-size: 48px;
          margin-bottom: 16px;
        }

        .connect-prompt p {
          font-size: 18px;
          color: #a0a0a0;
        }

        .create-form-container {
          max-width: 800px;
          margin: 0 auto;
        }

        .form-header {
          margin-bottom: 48px;
        }

        .form-header h1 {
          color: #fff;
          font-size: 48px;
          font-weight: 900;
          margin: 0 0 8px 0;
        }

        .form-header p {
          color: #a0a0a0;
          font-size: 18px;
        }

        .create-form {
          background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
          border-radius: 16px;
          padding: 32px;
        }

        .form-section {
          margin-bottom: 40px;
        }

        .form-section h2 {
          color: #fff;
          font-size: 24px;
          font-weight: 700;
          margin: 0 0 24px 0;
          padding-bottom: 16px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
        }

        .form-group {
          margin-bottom: 24px;
        }

        .form-group label {
          display: block;
          color: #fff;
          font-size: 14px;
          font-weight: 600;
          margin-bottom: 8px;
        }

        .form-group input,
        .form-group textarea {
          width: 100%;
          padding: 12px 16px;
          background: rgba(0, 0, 0, 0.3);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          color: #fff;
          font-size: 16px;
          transition: border-color 0.2s ease;
        }

        .form-group input:focus,
        .form-group textarea:focus {
          outline: none;
          border-color: #0052ff;
        }

        .form-group small {
          display: block;
          color: #a0a0a0;
          font-size: 12px;
          margin-top: 4px;
        }

        .checkbox-label {
          display: flex;
          align-items: center;
          gap: 12px;
          cursor: pointer;
        }

        .checkbox-label input[type="checkbox"] {
          width: 20px;
          height: 20px;
          cursor: pointer;
        }

        .checkbox-label span {
          color: #fff;
          font-size: 16px;
        }

        .error-message {
          background: rgba(255, 0, 0, 0.1);
          border: 1px solid #ff0000;
          border-radius: 8px;
          padding: 16px;
          color: #ff4444;
          margin-bottom: 24px;
        }

        .form-actions {
          display: flex;
          gap: 16px;
          justify-content: flex-end;
        }

        .cancel-button,
        .submit-button {
          padding: 14px 32px;
          border-radius: 8px;
          font-size: 16px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
          border: none;
        }

        .cancel-button {
          background: transparent;
          color: #a0a0a0;
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .cancel-button:hover:not(:disabled) {
          background: rgba(255, 255, 255, 0.05);
        }

        .submit-button {
          background: linear-gradient(135deg, #0052ff 0%, #0040cc 100%);
          color: #fff;
        }

        .submit-button:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(0, 82, 255, 0.4);
        }

        .cancel-button:disabled,
        .submit-button:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        @media (max-width: 768px) {
          .page-container {
            padding: 24px 16px;
          }

          .form-header h1 {
            font-size: 36px;
          }

          .create-form {
            padding: 24px;
          }

          .form-row {
            grid-template-columns: 1fr;
          }

          .form-actions {
            flex-direction: column-reverse;
          }

          .cancel-button,
          .submit-button {
            width: 100%;
          }
        }
      `}</style>
    </div>
  );
}
