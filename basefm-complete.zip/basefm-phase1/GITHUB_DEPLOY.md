# Push baseFM to GitHub & Deploy

## Step 1: Initialize Git Repository

```bash
cd basefm-phase1

# Initialize git
git init

# Add all files
git add .

# First commit
git commit -m "Initial commit - baseFM Phase 1-3 complete"
```

## Step 2: Create GitHub Repository

### Option A: Via GitHub Website

1. Go to https://github.com/new
2. Repository name: `basefm` (or whatever you want)
3. Description: "Onchain radio platform on Base"
4. **Keep it Private** (for now, until you're ready to open source)
5. **Do NOT** initialize with README (we already have one)
6. Click "Create repository"

### Option B: Via GitHub CLI (if installed)

```bash
gh repo create basefm --private --source=. --remote=origin
```

## Step 3: Connect Local to GitHub

```bash
# Add remote (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/basefm.git

# Push to GitHub
git branch -M main
git push -u origin main
```

## Step 4: Deploy to Vercel

### Quick Deploy

1. Go to https://vercel.com/new
2. Click "Import Git Repository"
3. Find your `basefm` repo
4. Click "Import"

### Configure Project

**Framework Preset:** Next.js (should auto-detect)

**Root Directory:** `./` (leave as is)

**Build Command:** `npm run build` (default)

**Environment Variables:** Add all from `.env.local`:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbG...
SUPABASE_SERVICE_ROLE_KEY=eyJhbG...

# Mux
MUX_TOKEN_ID=xxxxx
MUX_TOKEN_SECRET=xxxxx
MUX_WEBHOOK_SECRET=xxxxx

# Base
NEXT_PUBLIC_BASE_CHAIN_ID=8453
NEXT_PUBLIC_BASE_RPC_URL=https://mainnet.base.org

# App URL (will be your Vercel domain)
NEXT_PUBLIC_APP_URL=https://your-project.vercel.app
```

Click **Deploy**

## Step 5: Update Mux Webhook

Once deployed, update your Mux webhook:

1. Go to https://dashboard.mux.com
2. Settings → Webhooks
3. Find your webhook
4. Update URL to: `https://your-project.vercel.app/api/webhooks/mux`
5. Save

## Step 6: Test Production

```bash
# Create test stream
curl -X POST https://your-project.vercel.app/api/streams \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Production Test",
    "djName": "Test DJ",
    "djWalletAddress": "0x1234567890123456789012345678901234567890"
  }'

# Visit your site
open https://your-project.vercel.app
```

## Step 7: Custom Domain (Optional)

### Add Domain to Vercel

1. Vercel Dashboard → Your Project
2. Settings → Domains
3. Add your domain (e.g., `basefm.radio`)
4. Follow DNS instructions

### Update Environment Variables

```bash
# Update NEXT_PUBLIC_APP_URL
NEXT_PUBLIC_APP_URL=https://basefm.radio
```

### Update Mux Webhook Again

```
https://basefm.radio/api/webhooks/mux
```

## Continuous Deployment

**Automatic deploys** are now enabled!

Every push to `main` branch will automatically deploy to production.

```bash
# Make changes
git add .
git commit -m "Update AudioPlayer styling"
git push

# Vercel automatically deploys in ~2 minutes
```

## Branch Protection (Recommended)

### Create Development Branch

```bash
# Create dev branch
git checkout -b dev
git push -u origin dev
```

### Vercel Preview Deployments

- Pushes to `dev` → Preview deployment (not production)
- Pushes to `main` → Production deployment

### Workflow

```bash
# Work on features in dev
git checkout dev
# ... make changes ...
git add .
git commit -m "Add new feature"
git push

# Test preview deployment
# Visit: https://basefm-git-dev-yourname.vercel.app

# When ready for production
git checkout main
git merge dev
git push
```

## Environment Management

### Local Development

```bash
.env.local (not committed)
```

### Vercel Production

```
Project Settings → Environment Variables
```

### Vercel Preview (Optional)

Add separate env vars for preview branches if needed:

```
Preview: Different Supabase project
Production: Main Supabase project
```

## Rollback (If Something Breaks)

### Vercel Dashboard

1. Go to Deployments
2. Find last working deployment
3. Click "..." menu
4. Click "Promote to Production"

### Via Git

```bash
# Revert to last commit
git revert HEAD
git push

# Or hard reset (destructive)
git reset --hard HEAD~1
git push --force
```

## Security Checklist

Before going public:

- [ ] `.env.local` is in `.gitignore`
- [ ] No API keys committed to git
- [ ] Supabase RLS policies enabled
- [ ] Mux webhook signature verified
- [ ] CORS configured (if needed)
- [ ] Rate limiting added (future)

## Monitoring

### Vercel

- https://vercel.com/yourname/basefm/analytics
- https://vercel.com/yourname/basefm/logs

### Supabase

- https://supabase.com/dashboard/project/_/logs/explorer

### Mux

- https://dashboard.mux.com/logs

## Common Issues

### Push Rejected

**Error:** `error: failed to push some refs`

**Fix:**
```bash
git pull --rebase origin main
git push
```

### Vercel Build Failed

**Error:** `Build failed`

**Fix:**
1. Check build logs in Vercel dashboard
2. Verify all env vars are set
3. Test locally: `npm run build`

### Domain Not Working

**Error:** DNS not resolving

**Fix:**
1. Wait 24-48 hours for DNS propagation
2. Verify DNS records in domain registrar
3. Check Vercel domain status

## Getting Help

- Vercel Docs: https://vercel.com/docs
- GitHub Docs: https://docs.github.com
- Supabase Docs: https://supabase.com/docs
- Mux Docs: https://docs.mux.com

---

**You're all set!** Your baseFM is now live on the internet. 🎉
