// components/TokenGate.tsx
'use client';

import { ReactNode } from 'react';
import { useTokenGate } from '@/hooks/useTokenGate';

export interface TokenGateProps {
  tokenAddress: string;
  requiredAmount: number;
  children: ReactNode;
  fallback?: ReactNode;
  onAccessGranted?: () => void;
  onAccessDenied?: (error: string) => void;
}

export function TokenGate({
  tokenAddress,
  requiredAmount,
  children,
  fallback,
  onAccessGranted,
  onAccessDenied,
}: TokenGateProps) {
  const { hasAccess, isChecking, error, tokenInfo, checkAccess } = useTokenGate({
    tokenAddress,
    requiredAmount,
    enabled: true,
  });

  // Callbacks
  if (hasAccess && onAccessGranted) {
    onAccessGranted();
  }

  if (error && onAccessDenied) {
    onAccessDenied(error);
  }

  // Loading state
  if (isChecking) {
    return (
      <div className="token-gate-loading">
        <div className="spinner" />
        <p>Checking token balance...</p>

        <style jsx>{`
          .token-gate-loading {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 48px;
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
            border-radius: 16px;
            color: #fff;
          }

          .spinner {
            width: 48px;
            height: 48px;
            border: 4px solid #333;
            border-top-color: #0052ff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 16px;
          }

          @keyframes spin {
            to {
              transform: rotate(360deg);
            }
          }

          p {
            color: #a0a0a0;
            font-size: 16px;
          }
        `}</style>
      </div>
    );
  }

  // Access granted - show content
  if (hasAccess) {
    return <>{children}</>;
  }

  // Access denied - show fallback or default message
  if (fallback) {
    return <>{fallback}</>;
  }

  return (
    <div className="token-gate-denied">
      <div className="icon">🔒</div>
      <h2>Token Required</h2>
      <p className="message">
        You need{' '}
        <span className="highlight">
          {requiredAmount} {tokenInfo?.tokenInfo.symbol || 'tokens'}
        </span>{' '}
        to access this stream.
      </p>

      {tokenInfo && (
        <div className="balance-info">
          <div className="balance-row">
            <span className="label">Your Balance:</span>
            <span className="value">
              {tokenInfo.formattedBalance} {tokenInfo.tokenInfo.symbol}
            </span>
          </div>
          <div className="balance-row">
            <span className="label">Required:</span>
            <span className="value">
              {requiredAmount} {tokenInfo.tokenInfo.symbol}
            </span>
          </div>
          <div className="balance-row">
            <span className="label">Token:</span>
            <span className="value token-name">{tokenInfo.tokenInfo.name}</span>
          </div>
        </div>
      )}

      {error && <p className="error">{error}</p>}

      <button onClick={checkAccess} className="retry-button">
        Check Again
      </button>

      <div className="help-text">
        <p>Need tokens? Visit the token contract:</p>
        <a
          href={`https://basescan.org/address/${tokenAddress}`}
          target="_blank"
          rel="noopener noreferrer"
          className="contract-link"
        >
          {tokenAddress.slice(0, 6)}...{tokenAddress.slice(-4)} ↗
        </a>
      </div>

      <style jsx>{`
        .token-gate-denied {
          display: flex;
          flex-direction: column;
          align-items: center;
          padding: 64px 32px;
          background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
          border-radius: 16px;
          text-align: center;
          max-width: 600px;
          margin: 0 auto;
        }

        .icon {
          font-size: 64px;
          margin-bottom: 24px;
        }

        h2 {
          color: #fff;
          font-size: 32px;
          font-weight: 700;
          margin: 0 0 16px 0;
        }

        .message {
          color: #a0a0a0;
          font-size: 18px;
          margin: 0 0 32px 0;
          line-height: 1.6;
        }

        .highlight {
          color: #0052ff;
          font-weight: 700;
        }

        .balance-info {
          width: 100%;
          background: rgba(0, 0, 0, 0.3);
          border-radius: 12px;
          padding: 24px;
          margin-bottom: 24px;
        }

        .balance-row {
          display: flex;
          justify-content: space-between;
          padding: 12px 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .balance-row:last-child {
          border-bottom: none;
        }

        .label {
          color: #a0a0a0;
          font-size: 14px;
        }

        .value {
          color: #fff;
          font-size: 14px;
          font-weight: 600;
        }

        .token-name {
          font-family: monospace;
          font-size: 12px;
        }

        .error {
          color: #ff4444;
          font-size: 14px;
          margin: 0 0 16px 0;
          padding: 12px;
          background: rgba(255, 0, 0, 0.1);
          border-radius: 8px;
          width: 100%;
        }

        .retry-button {
          padding: 16px 48px;
          background: linear-gradient(135deg, #0052ff 0%, #0040cc 100%);
          color: #fff;
          border: none;
          border-radius: 12px;
          font-size: 16px;
          font-weight: 700;
          cursor: pointer;
          transition: transform 0.2s ease, box-shadow 0.2s ease;
          margin-bottom: 32px;
        }

        .retry-button:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(0, 82, 255, 0.4);
        }

        .help-text {
          padding-top: 24px;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
          width: 100%;
        }

        .help-text p {
          color: #a0a0a0;
          font-size: 14px;
          margin: 0 0 8px 0;
        }

        .contract-link {
          color: #0052ff;
          text-decoration: none;
          font-family: monospace;
          font-size: 14px;
        }

        .contract-link:hover {
          text-decoration: underline;
        }
      `}</style>
    </div>
  );
}
