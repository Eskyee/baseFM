// components/StreamCard.tsx
'use client';

import Link from 'next/link';
import type { Stream } from '@/types/stream';

export interface StreamCardProps {
  stream: Stream;
  listenerCount?: number;
  onClick?: () => void;
}

export function StreamCard({ stream, listenerCount, onClick }: StreamCardProps) {
  const isLive = stream.status === 'LIVE';
  const isPreparing = stream.status === 'PREPARING';
  const isEnded = stream.status === 'ENDED';

  const statusColor = isLive
    ? '#00ff00'
    : isPreparing
    ? '#ffaa00'
    : isEnded
    ? '#666666'
    : '#0052ff';

  const statusText = isLive
    ? 'LIVE'
    : isPreparing
    ? 'STARTING SOON'
    : isEnded
    ? 'ENDED'
    : 'SCHEDULED';

  return (
    <Link href={`/stream/${stream.id}`} onClick={onClick}>
      <div className="stream-card">
        {/* Cover Image */}
        <div className="cover-container">
          {stream.coverImageUrl ? (
            <img
              src={stream.coverImageUrl}
              alt={stream.title}
              className="cover-image"
            />
          ) : (
            <div className="cover-placeholder">
              <MusicIcon />
            </div>
          )}
          
          {/* Status Badge */}
          <div className="status-badge" style={{ background: statusColor }}>
            {isLive && <LiveDot />}
            <span>{statusText}</span>
          </div>

          {/* Gated Badge */}
          {stream.isGated && (
            <div className="gated-badge">
              <span>🔒 Token Gated</span>
            </div>
          )}

          {/* Listener Count (if live) */}
          {isLive && listenerCount !== undefined && (
            <div className="listener-count">
              <ListenerIcon />
              <span>{formatListenerCount(listenerCount)}</span>
            </div>
          )}
        </div>

        {/* Stream Info */}
        <div className="stream-info">
          <h3 className="stream-title">{stream.title}</h3>
          <p className="dj-name">{stream.djName}</p>
          
          {stream.genre && (
            <span className="genre-tag">{stream.genre}</span>
          )}
        </div>

        <style jsx>{`
          .stream-card {
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
            border-radius: 16px;
            overflow: hidden;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            display: block;
            text-decoration: none;
          }

          .stream-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
          }

          .cover-container {
            position: relative;
            width: 100%;
            aspect-ratio: 1;
            background: #000;
          }

          .cover-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }

          .cover-placeholder {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #2d2d2d 0%, #1a1a1a 100%);
          }

          .status-badge {
            position: absolute;
            top: 12px;
            left: 12px;
            padding: 6px 12px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            font-weight: 700;
            color: #000;
            letter-spacing: 0.5px;
          }

          .gated-badge {
            position: absolute;
            bottom: 12px;
            left: 12px;
            padding: 6px 12px;
            border-radius: 20px;
            background: rgba(255, 165, 0, 0.9);
            backdrop-filter: blur(8px);
            font-size: 12px;
            font-weight: 700;
            color: #000;
          }

          .listener-count {
            position: absolute;
            top: 12px;
            right: 12px;
            padding: 6px 12px;
            border-radius: 20px;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(8px);
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            font-weight: 600;
            color: #fff;
          }

          .stream-info {
            padding: 16px;
          }

          .stream-title {
            color: #fff;
            font-size: 18px;
            font-weight: 700;
            margin: 0 0 8px 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }

          .dj-name {
            color: #a0a0a0;
            font-size: 14px;
            margin: 0 0 12px 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }

          .genre-tag {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            background: rgba(0, 82, 255, 0.2);
            color: #0052ff;
            font-size: 12px;
            font-weight: 600;
          }
        `}</style>
      </div>
    </Link>
  );
}

function LiveDot() {
  return (
    <>
      <span className="live-dot"></span>
      <style jsx>{`
        .live-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #000;
          animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {
          0%, 100% {
            opacity: 1;
            transform: scale(1);
          }
          50% {
            opacity: 0.6;
            transform: scale(1.2);
          }
        }
      `}</style>
    </>
  );
}

function MusicIcon() {
  return (
    <svg width="64" height="64" viewBox="0 0 24 24" fill="none">
      <path
        d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"
        fill="#666"
      />
    </svg>
  );
}

function ListenerIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
      <path
        d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"
        fill="currentColor"
      />
    </svg>
  );
}

function formatListenerCount(count: number): string {
  if (count >= 1000000) {
    return `${(count / 1000000).toFixed(1)}M`;
  }
  if (count >= 1000) {
    return `${(count / 1000).toFixed(1)}K`;
  }
  return count.toString();
}
