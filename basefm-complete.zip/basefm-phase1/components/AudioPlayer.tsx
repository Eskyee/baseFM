// components/AudioPlayer.tsx
'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import Hls from 'hls.js';

export interface AudioPlayerProps {
  streamUrl: string;
  title?: string;
  djName?: string;
  coverImage?: string;
  autoPlay?: boolean;
  onPlay?: () => void;
  onPause?: () => void;
  onError?: (error: string) => void;
}

export function AudioPlayer({
  streamUrl,
  title = 'Live Stream',
  djName,
  coverImage,
  autoPlay = false,
  onPlay,
  onPause,
  onError,
}: AudioPlayerProps) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [volume, setVolume] = useState(1);
  const [retryCount, setRetryCount] = useState(0);
  
  const maxRetries = 3;
  const retryDelay = 2000; // 2 seconds

  /**
   * Initialize HLS.js player
   */
  const initializePlayer = useCallback(() => {
    const audio = audioRef.current;
    if (!audio || !streamUrl) return;

    // Clean up existing HLS instance
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    setError(null);
    setIsLoading(true);

    // Check if HLS is natively supported (Safari)
    if (audio.canPlayType('application/vnd.apple.mpegurl')) {
      audio.src = streamUrl;
      
      audio.addEventListener('loadedmetadata', () => {
        setIsLoading(false);
        if (autoPlay) {
          audio.play().catch(handlePlayError);
        }
      });

      audio.addEventListener('error', () => {
        handleError('Native HLS playback failed');
      });

    } else if (Hls.isSupported()) {
      // Use HLS.js for browsers that don't support native HLS
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 90,
        maxBufferLength: 30,
        maxMaxBufferLength: 60,
        // Aggressive retry for live streams
        manifestLoadingTimeOut: 10000,
        manifestLoadingMaxRetry: 5,
        manifestLoadingRetryDelay: 500,
        levelLoadingTimeOut: 10000,
        levelLoadingMaxRetry: 5,
        levelLoadingRetryDelay: 500,
        fragLoadingTimeOut: 20000,
        fragLoadingMaxRetry: 6,
        fragLoadingRetryDelay: 500,
      });

      hlsRef.current = hls;

      // HLS.js event handlers
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setIsLoading(false);
        setRetryCount(0); // Reset retry count on success
        
        if (autoPlay) {
          audio.play().catch(handlePlayError);
        }
      });

      hls.on(Hls.Events.ERROR, (event, data) => {
        console.error('HLS error:', data);

        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              // Network error - try to recover
              console.log('Network error, attempting to recover...');
              if (retryCount < maxRetries) {
                setTimeout(() => {
                  hls.startLoad();
                  setRetryCount((prev) => prev + 1);
                }, retryDelay * (retryCount + 1)); // Exponential backoff
              } else {
                handleError('Network connection failed after multiple retries');
              }
              break;

            case Hls.ErrorTypes.MEDIA_ERROR:
              // Media error - try to recover
              console.log('Media error, attempting to recover...');
              hls.recoverMediaError();
              break;

            default:
              // Fatal error - cannot recover
              handleError('Playback failed. Please try again.');
              break;
          }
        }
      });

      // Load the stream
      hls.loadSource(streamUrl);
      hls.attachMedia(audio);

    } else {
      handleError('HLS playback is not supported in this browser');
    }
  }, [streamUrl, autoPlay, retryCount]);

  /**
   * Handle playback errors (autoplay blocked, etc)
   */
  const handlePlayError = (err: Error) => {
    console.error('Play error:', err);
    // Autoplay was probably blocked - this is normal, user needs to click play
    setIsPlaying(false);
    setIsLoading(false);
  };

  /**
   * Handle fatal errors
   */
  const handleError = (message: string) => {
    setError(message);
    setIsLoading(false);
    setIsPlaying(false);
    onError?.(message);
  };

  /**
   * Play/Pause toggle
   */
  const togglePlayPause = async () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
    } else {
      try {
        await audio.play();
      } catch (err) {
        handlePlayError(err as Error);
      }
    }
  };

  /**
   * Volume control
   */
  const handleVolumeChange = (newVolume: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    
    audio.volume = newVolume;
    setVolume(newVolume);
  };

  /**
   * Initialize player on mount or when streamUrl changes
   */
  useEffect(() => {
    initializePlayer();

    // Cleanup on unmount
    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [initializePlayer]);

  /**
   * Audio element event listeners
   */
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handlePlay = () => {
      setIsPlaying(true);
      setIsLoading(false);
      onPlay?.();
    };

    const handlePause = () => {
      setIsPlaying(false);
      onPause?.();
    };

    const handleWaiting = () => {
      setIsLoading(true);
    };

    const handleCanPlay = () => {
      setIsLoading(false);
    };

    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('waiting', handleWaiting);
    audio.addEventListener('canplay', handleCanPlay);

    return () => {
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('waiting', handleWaiting);
      audio.removeEventListener('canplay', handleCanPlay);
    };
  }, [onPlay, onPause]);

  return (
    <div className="audio-player">
      {/* Hidden audio element */}
      <audio ref={audioRef} />

      {/* Player UI */}
      <div className="player-container">
        {/* Cover Art */}
        {coverImage && (
          <div className="cover-art">
            <img src={coverImage} alt={title} />
          </div>
        )}

        {/* Stream Info */}
        <div className="stream-info">
          <h3 className="stream-title">{title}</h3>
          {djName && <p className="dj-name">{djName}</p>}
          {error && <p className="error-message">{error}</p>}
        </div>

        {/* Controls */}
        <div className="controls">
          {/* Play/Pause Button */}
          <button
            onClick={togglePlayPause}
            disabled={!!error || isLoading}
            className="play-button"
            aria-label={isPlaying ? 'Pause' : 'Play'}
          >
            {isLoading ? (
              <LoadingSpinner />
            ) : isPlaying ? (
              <PauseIcon />
            ) : (
              <PlayIcon />
            )}
          </button>

          {/* Volume Control */}
          <div className="volume-control">
            <VolumeIcon />
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={volume}
              onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
              className="volume-slider"
              aria-label="Volume"
            />
          </div>

          {/* Live Indicator */}
          <div className="live-indicator">
            <span className="live-dot"></span>
            <span className="live-text">LIVE</span>
          </div>
        </div>
      </div>

      <style jsx>{`
        .audio-player {
          width: 100%;
          max-width: 600px;
        }

        .player-container {
          background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
          border-radius: 16px;
          padding: 24px;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .cover-art {
          width: 100%;
          aspect-ratio: 1;
          border-radius: 12px;
          overflow: hidden;
          margin-bottom: 20px;
        }

        .cover-art img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .stream-info {
          margin-bottom: 20px;
        }

        .stream-title {
          color: #ffffff;
          font-size: 24px;
          font-weight: 700;
          margin: 0 0 8px 0;
        }

        .dj-name {
          color: #a0a0a0;
          font-size: 16px;
          margin: 0;
        }

        .error-message {
          color: #ff4444;
          font-size: 14px;
          margin: 8px 0 0 0;
        }

        .controls {
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .play-button {
          width: 64px;
          height: 64px;
          border-radius: 50%;
          background: linear-gradient(135deg, #0052ff 0%, #0040cc 100%);
          border: none;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: transform 0.2s ease, box-shadow 0.2s ease;
          flex-shrink: 0;
        }

        .play-button:hover:not(:disabled) {
          transform: scale(1.05);
          box-shadow: 0 4px 16px rgba(0, 82, 255, 0.4);
        }

        .play-button:active:not(:disabled) {
          transform: scale(0.98);
        }

        .play-button:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .volume-control {
          display: flex;
          align-items: center;
          gap: 12px;
          flex: 1;
        }

        .volume-slider {
          flex: 1;
          height: 4px;
          border-radius: 2px;
          background: #404040;
          outline: none;
          -webkit-appearance: none;
        }

        .volume-slider::-webkit-slider-thumb {
          -webkit-appearance: none;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #0052ff;
          cursor: pointer;
        }

        .volume-slider::-moz-range-thumb {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #0052ff;
          border: none;
          cursor: pointer;
        }

        .live-indicator {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 16px;
          background: rgba(255, 0, 0, 0.1);
          border-radius: 20px;
          flex-shrink: 0;
        }

        .live-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #ff0000;
          animation: pulse 2s ease-in-out infinite;
        }

        .live-text {
          color: #ff0000;
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 0.5px;
        }

        @keyframes pulse {
          0%, 100% {
            opacity: 1;
            transform: scale(1);
          }
          50% {
            opacity: 0.6;
            transform: scale(1.2);
          }
        }
      `}</style>
    </div>
  );
}

// Icon Components
function PlayIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <path d="M8 5v14l11-7z" fill="white" />
    </svg>
  );
}

function PauseIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <path d="M6 4h4v16H6zM14 4h4v16h-4z" fill="white" />
    </svg>
  );
}

function VolumeIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <path
        d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z"
        fill="#a0a0a0"
      />
    </svg>
  );
}

function LoadingSpinner() {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      className="loading-spinner"
    >
      <circle
        cx="12"
        cy="12"
        r="10"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeDasharray="31.4 31.4"
      />
      <style jsx>{`
        .loading-spinner {
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }
      `}</style>
    </svg>
  );
}
