// components/Navbar.tsx
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { WalletConnect } from './WalletConnect';

export function Navbar() {
  const pathname = usePathname();

  const isActive = (path: string) => pathname === path;

  return (
    <nav className="navbar">
      <div className="navbar-container">
        {/* Logo */}
        <Link href="/" className="logo">
          <span className="logo-text">baseFM</span>
        </Link>

        {/* Navigation Links */}
        <div className="nav-links">
          <Link
            href="/"
            className={`nav-link ${isActive('/') ? 'active' : ''}`}
          >
            Discover
          </Link>
          <Link
            href="/dj"
            className={`nav-link ${isActive('/dj') ? 'active' : ''}`}
          >
            DJ Dashboard
          </Link>
        </div>

        {/* Wallet Connect */}
        <WalletConnect />
      </div>

      <style jsx>{`
        .navbar {
          position: sticky;
          top: 0;
          z-index: 100;
          background: rgba(10, 10, 10, 0.9);
          backdrop-filter: blur(12px);
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .navbar-container {
          max-width: 1400px;
          margin: 0 auto;
          padding: 16px 24px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 32px;
        }

        .logo {
          text-decoration: none;
        }

        .logo-text {
          font-size: 24px;
          font-weight: 900;
          background: linear-gradient(135deg, #0052ff 0%, #00ffff 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          letter-spacing: -0.5px;
        }

        .nav-links {
          display: flex;
          gap: 24px;
          flex: 1;
        }

        .nav-link {
          color: #a0a0a0;
          text-decoration: none;
          font-size: 16px;
          font-weight: 600;
          transition: color 0.2s ease;
          position: relative;
        }

        .nav-link:hover {
          color: #ffffff;
        }

        .nav-link.active {
          color: #0052ff;
        }

        .nav-link.active::after {
          content: '';
          position: absolute;
          bottom: -20px;
          left: 0;
          right: 0;
          height: 2px;
          background: #0052ff;
        }

        @media (max-width: 768px) {
          .navbar-container {
            padding: 12px 16px;
          }

          .nav-links {
            gap: 16px;
          }

          .nav-link {
            font-size: 14px;
          }

          .logo-text {
            font-size: 20px;
          }
        }
      `}</style>
    </nav>
  );
}
