// types/user.ts
export interface User {
  walletAddress: string;
  displayName?: string;
  avatarUrl?: string;
  
  // Stats
  streamsHosted?: number;
  totalListenTime?: number; // minutes
  
  // Metadata
  bio?: string;
  links?: {
    twitter?: string;
    farcaster?: string;
    website?: string;
  };
}

// types/token.ts
export interface Token {
  address: string;
  chainId: number;
  name: string;
  symbol: string;
  decimals: number;
  logoUrl?: string;
}

export interface TokenBalance {
  token: Token;
  balance: string; // Raw balance as string to avoid precision issues
  formattedBalance: string; // Human-readable balance
}

export interface TokenGateConfig {
  enabled: boolean;
  tokenAddress: string;
  requiredAmount: number;
  chainId?: number;
}
