// types/stream.ts
// Stream status lifecycle
export type StreamStatus = 'CREATED' | 'PREPARING' | 'LIVE' | 'ENDING' | 'ENDED';

// Activity event types
export type StreamActivityType = 
  | 'CREATED' 
  | 'STARTED' 
  | 'ENDED' 
  | 'LISTENER_JOINED' 
  | 'LISTENER_LEFT';

// Main stream interface matching database schema
export interface Stream {
  id: string;
  
  // Basic info
  title: string;
  description?: string;
  djName: string;
  djWalletAddress: string;
  
  // Streaming
  status: StreamStatus;
  muxLiveStreamId?: string;
  muxStreamKey?: string;
  muxPlaybackId?: string;
  rtmpUrl?: string;
  hlsPlaybackUrl?: string;
  
  // Scheduling
  scheduledStartTime?: string; // ISO 8601
  actualStartTime?: string;
  actualEndTime?: string;
  
  // Token gating
  isGated: boolean;
  requiredTokenAddress?: string;
  requiredTokenAmount?: number;
  
  // Metadata
  coverImageUrl?: string;
  genre?: string;
  tags?: string[];
  
  // Timestamps
  createdAt: string;
  updatedAt: string;
}

// Event interface
export interface Event {
  id: string;
  streamId: string;
  title: string;
  description?: string;
  scheduledTime: string;
  duration?: number; // minutes
  recurring?: boolean;
  coverImageUrl?: string;
  createdAt: string;
  updatedAt: string;
}

// Stream activity log
export interface StreamActivity {
  id: string;
  streamId: string;
  eventType: StreamActivityType;
  metadata?: Record<string, any>;
  timestamp: string;
}

// API request/response types
export interface CreateStreamRequest {
  title: string;
  description?: string;
  djName: string;
  djWalletAddress: string;
  scheduledStartTime?: string;
  isGated?: boolean;
  requiredTokenAddress?: string;
  requiredTokenAmount?: number;
  coverImageUrl?: string;
  genre?: string;
  tags?: string[];
}

export interface CreateStreamResponse {
  stream: Stream;
  rtmpUrl?: string;
  rtmpKey?: string;
}

export interface StartStreamRequest {
  djWalletAddress: string;
  signature: string; // Wallet signature for verification
}

export interface StartStreamResponse {
  stream: Stream;
  rtmpUrl: string;
  rtmpKey: string;
}

export interface UpdateStreamRequest {
  title?: string;
  description?: string;
  coverImageUrl?: string;
  genre?: string;
  tags?: string[];
}

// Frontend component props
export interface StreamWithListenerCount extends Stream {
  listenerCount?: number;
}

// Database query filters
export interface StreamQueryParams {
  status?: StreamStatus;
  djWalletAddress?: string;
  limit?: number;
  offset?: number;
}

// Mux webhook payload types
export interface MuxWebhookPayload {
  type: string;
  object: {
    type: string;
    id: string;
  };
  data: {
    id: string;
    status?: string;
    stream_key?: string;
    playback_ids?: Array<{
      id: string;
      policy: string;
    }>;
  };
  created_at: string;
}
