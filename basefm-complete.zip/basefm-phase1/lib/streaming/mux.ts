// lib/streaming/mux.ts
import Mux from '@mux/mux-node';

// Initialize Mux client
const mux = new Mux({
  tokenId: process.env.MUX_TOKEN_ID!,
  tokenSecret: process.env.MUX_TOKEN_SECRET!,
});

export interface MuxLiveStream {
  id: string;
  streamKey: string;
  playbackId: string;
  rtmpUrl: string;
  status: 'idle' | 'active' | 'disabled';
}

/**
 * Create a new Mux live stream
 * Returns RTMP ingest URL and HLS playback URL
 */
export async function createMuxLiveStream(streamId: string): Promise<MuxLiveStream> {
  try {
    const liveStream = await mux.video.liveStreams.create({
      playback_policy: ['public'], // Public HLS playback
      new_asset_settings: {
        playback_policy: ['public'], // Recording also public
      },
      reconnect_window: 300, // 5 minutes to reconnect
      reduced_latency: true, // Enable low-latency mode
      // Pass through metadata for webhook correlation
      passthrough: JSON.stringify({ baseFmStreamId: streamId }),
    });

    if (!liveStream.stream_key) {
      throw new Error('Mux did not return stream key');
    }

    if (!liveStream.playback_ids || liveStream.playback_ids.length === 0) {
      throw new Error('Mux did not return playback ID');
    }

    return {
      id: liveStream.id,
      streamKey: liveStream.stream_key,
      playbackId: liveStream.playback_ids[0].id,
      rtmpUrl: `rtmps://global-live.mux.com:443/app/${liveStream.stream_key}`,
      status: liveStream.status as 'idle' | 'active' | 'disabled',
    };
  } catch (error) {
    console.error('Error creating Mux live stream:', error);
    throw new Error('Failed to create live stream');
  }
}

/**
 * Get Mux live stream status
 */
export async function getMuxLiveStreamStatus(muxLiveStreamId: string): Promise<'idle' | 'active' | 'disabled'> {
  try {
    const liveStream = await mux.video.liveStreams.retrieve(muxLiveStreamId);
    return liveStream.status as 'idle' | 'active' | 'disabled';
  } catch (error) {
    console.error('Error getting Mux live stream status:', error);
    throw new Error('Failed to get stream status');
  }
}

/**
 * Delete a Mux live stream
 */
export async function deleteMuxLiveStream(muxLiveStreamId: string): Promise<void> {
  try {
    await mux.video.liveStreams.delete(muxLiveStreamId);
  } catch (error) {
    console.error('Error deleting Mux live stream:', error);
    throw new Error('Failed to delete stream');
  }
}

/**
 * Get HLS playback URL from Mux playback ID
 */
export function getMuxPlaybackUrl(playbackId: string): string {
  return `https://stream.mux.com/${playbackId}.m3u8`;
}

/**
 * Verify Mux webhook signature
 */
export function verifyMuxWebhookSignature(
  body: string,
  signature: string,
  secret: string = process.env.MUX_WEBHOOK_SECRET!
): boolean {
  try {
    return Mux.Webhooks.verifyHeader(body, signature, secret);
  } catch (error) {
    console.error('Error verifying Mux webhook signature:', error);
    return false;
  }
}

/**
 * Parse Mux webhook event type
 */
export function parseMuxWebhookEvent(payload: any): {
  type: 'stream_active' | 'stream_idle' | 'stream_disconnected' | 'asset_created' | 'unknown';
  liveStreamId?: string;
  baseFmStreamId?: string;
} {
  const eventType = payload.type;
  const liveStreamId = payload.data?.id;
  
  // Extract our stream ID from passthrough metadata
  let baseFmStreamId: string | undefined;
  try {
    if (payload.data?.passthrough) {
      const passthrough = JSON.parse(payload.data.passthrough);
      baseFmStreamId = passthrough.baseFmStreamId;
    }
  } catch (e) {
    console.warn('Could not parse passthrough metadata');
  }

  // Map Mux event types to our internal types
  let type: 'stream_active' | 'stream_idle' | 'stream_disconnected' | 'asset_created' | 'unknown' = 'unknown';
  
  if (eventType === 'video.live_stream.active') {
    type = 'stream_active';
  } else if (eventType === 'video.live_stream.idle') {
    type = 'stream_idle';
  } else if (eventType === 'video.live_stream.disconnected') {
    type = 'stream_disconnected';
  } else if (eventType === 'video.asset.created') {
    type = 'asset_created';
  }

  return {
    type,
    liveStreamId,
    baseFmStreamId,
  };
}

/**
 * Get estimated viewer count from Mux
 * Note: This requires Mux Data API access
 */
export async function getMuxViewerCount(liveStreamId: string): Promise<number> {
  try {
    // This is a placeholder - actual implementation requires Mux Data API
    // For now, we'll track this in our own database via stream_activity table
    return 0;
  } catch (error) {
    console.error('Error getting Mux viewer count:', error);
    return 0;
  }
}
