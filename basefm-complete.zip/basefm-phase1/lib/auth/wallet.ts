// lib/auth/wallet.ts
import { verifyMessage } from 'viem';
import { type Address } from 'viem';

/**
 * Generate a message for wallet signing
 * This message should be signed by the DJ to prove ownership
 */
export function generateSignatureMessage(streamId: string, action: string): string {
  const timestamp = Date.now();
  return `baseFM DJ Action\n\nStream ID: ${streamId}\nAction: ${action}\nTimestamp: ${timestamp}\n\nBy signing this message, you confirm you are authorized to perform this action.`;
}

/**
 * Verify wallet signature
 * Returns true if signature is valid for the given message and address
 */
export async function verifyWalletSignature(
  message: string,
  signature: `0x${string}`,
  expectedAddress: Address
): Promise<boolean> {
  try {
    const isValid = await verifyMessage({
      address: expectedAddress,
      message,
      signature,
    });
    return isValid;
  } catch (error) {
    console.error('Error verifying wallet signature:', error);
    return false;
  }
}

/**
 * Verify DJ owns the stream
 */
export async function verifyDjOwnership(
  streamId: string,
  djWalletAddress: Address,
  signature: `0x${string}`,
  message: string
): Promise<boolean> {
  // First verify the signature is valid
  const isValidSignature = await verifyWalletSignature(message, signature, djWalletAddress);
  
  if (!isValidSignature) {
    return false;
  }

  // Verify the message contains the correct stream ID
  if (!message.includes(streamId)) {
    return false;
  }

  return true;
}

/**
 * Check if wallet address format is valid
 */
export function isValidWalletAddress(address: string): address is Address {
  return /^0x[a-fA-F0-9]{40}$/.test(address);
}

/**
 * Normalize wallet address (lowercase)
 */
export function normalizeAddress(address: string): Address {
  if (!isValidWalletAddress(address)) {
    throw new Error('Invalid wallet address format');
  }
  return address.toLowerCase() as Address;
}
