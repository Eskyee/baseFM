// lib/db/streams.ts
import { supabaseAdmin } from '../supabase/client';
import type { Stream, StreamQueryParams, CreateStreamRequest, StreamActivity } from '../../types/stream';

/**
 * Convert snake_case database row to camelCase Stream object
 */
function mapDbRowToStream(row: any): Stream {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    djName: row.dj_name,
    djWalletAddress: row.dj_wallet_address,
    status: row.status,
    muxLiveStreamId: row.mux_live_stream_id,
    muxStreamKey: row.mux_stream_key,
    muxPlaybackId: row.mux_playback_id,
    rtmpUrl: row.rtmp_url,
    hlsPlaybackUrl: row.hls_playback_url,
    scheduledStartTime: row.scheduled_start_time,
    actualStartTime: row.actual_start_time,
    actualEndTime: row.actual_end_time,
    isGated: row.is_gated,
    requiredTokenAddress: row.required_token_address,
    requiredTokenAmount: row.required_token_amount,
    coverImageUrl: row.cover_image_url,
    genre: row.genre,
    tags: row.tags,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

/**
 * Get all streams with optional filters
 */
export async function getStreams(params: StreamQueryParams = {}): Promise<Stream[]> {
  let query = supabaseAdmin.from('streams').select('*');

  if (params.status) {
    query = query.eq('status', params.status);
  }

  if (params.djWalletAddress) {
    query = query.eq('dj_wallet_address', params.djWalletAddress);
  }

  const limit = params.limit || 50;
  const offset = params.offset || 0;

  query = query
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);

  const { data, error } = await query;

  if (error) {
    console.error('Error fetching streams:', error);
    throw new Error('Failed to fetch streams');
  }

  return data ? data.map(mapDbRowToStream) : [];
}

/**
 * Get a single stream by ID
 */
export async function getStreamById(streamId: string): Promise<Stream | null> {
  const { data, error } = await supabaseAdmin
    .from('streams')
    .select('*')
    .eq('id', streamId)
    .single();

  if (error) {
    if (error.code === 'PGRST116') {
      return null; // Not found
    }
    console.error('Error fetching stream:', error);
    throw new Error('Failed to fetch stream');
  }

  return data ? mapDbRowToStream(data) : null;
}

/**
 * Get live streams
 */
export async function getLiveStreams(): Promise<Stream[]> {
  return getStreams({ status: 'LIVE' });
}

/**
 * Create a new stream
 */
export async function createStream(request: CreateStreamRequest): Promise<Stream> {
  const { data, error } = await supabaseAdmin
    .from('streams')
    .insert({
      title: request.title,
      description: request.description,
      dj_name: request.djName,
      dj_wallet_address: request.djWalletAddress,
      status: 'CREATED',
      scheduled_start_time: request.scheduledStartTime,
      is_gated: request.isGated || false,
      required_token_address: request.requiredTokenAddress,
      required_token_amount: request.requiredTokenAmount,
      cover_image_url: request.coverImageUrl,
      genre: request.genre,
      tags: request.tags,
    })
    .select()
    .single();

  if (error) {
    console.error('Error creating stream:', error);
    throw new Error('Failed to create stream');
  }

  // Log activity
  await logStreamActivity({
    streamId: data.id,
    eventType: 'CREATED',
    metadata: {
      djWalletAddress: request.djWalletAddress,
    },
  });

  return mapDbRowToStream(data);
}

/**
 * Update stream with Mux details
 */
export async function updateStreamWithMuxDetails(
  streamId: string,
  muxDetails: {
    muxLiveStreamId: string;
    muxStreamKey: string;
    muxPlaybackId: string;
    rtmpUrl: string;
    hlsPlaybackUrl: string;
  }
): Promise<Stream> {
  const { data, error } = await supabaseAdmin
    .from('streams')
    .update({
      mux_live_stream_id: muxDetails.muxLiveStreamId,
      mux_stream_key: muxDetails.muxStreamKey,
      mux_playback_id: muxDetails.muxPlaybackId,
      rtmp_url: muxDetails.rtmpUrl,
      hls_playback_url: muxDetails.hlsPlaybackUrl,
      status: 'PREPARING',
    })
    .eq('id', streamId)
    .select()
    .single();

  if (error) {
    console.error('Error updating stream with Mux details:', error);
    throw new Error('Failed to update stream');
  }

  return mapDbRowToStream(data);
}

/**
 * Update stream status
 */
export async function updateStreamStatus(streamId: string, status: Stream['status']): Promise<Stream> {
  const updateData: any = { status };

  // Set timestamps based on status
  if (status === 'LIVE') {
    updateData.actual_start_time = new Date().toISOString();
  } else if (status === 'ENDING' || status === 'ENDED') {
    updateData.actual_end_time = new Date().toISOString();
  }

  const { data, error } = await supabaseAdmin
    .from('streams')
    .update(updateData)
    .eq('id', streamId)
    .select()
    .single();

  if (error) {
    console.error('Error updating stream status:', error);
    throw new Error('Failed to update stream status');
  }

  // Log activity
  if (status === 'LIVE') {
    await logStreamActivity({
      streamId,
      eventType: 'STARTED',
    });
  } else if (status === 'ENDED') {
    await logStreamActivity({
      streamId,
      eventType: 'ENDED',
    });
  }

  return mapDbRowToStream(data);
}

/**
 * Update stream metadata
 */
export async function updateStream(
  streamId: string,
  updates: {
    title?: string;
    description?: string;
    coverImageUrl?: string;
    genre?: string;
    tags?: string[];
  }
): Promise<Stream> {
  const updateData: any = {};

  if (updates.title !== undefined) updateData.title = updates.title;
  if (updates.description !== undefined) updateData.description = updates.description;
  if (updates.coverImageUrl !== undefined) updateData.cover_image_url = updates.coverImageUrl;
  if (updates.genre !== undefined) updateData.genre = updates.genre;
  if (updates.tags !== undefined) updateData.tags = updates.tags;

  const { data, error } = await supabaseAdmin
    .from('streams')
    .update(updateData)
    .eq('id', streamId)
    .select()
    .single();

  if (error) {
    console.error('Error updating stream:', error);
    throw new Error('Failed to update stream');
  }

  return mapDbRowToStream(data);
}

/**
 * Delete a stream
 */
export async function deleteStream(streamId: string): Promise<void> {
  const { error } = await supabaseAdmin
    .from('streams')
    .delete()
    .eq('id', streamId);

  if (error) {
    console.error('Error deleting stream:', error);
    throw new Error('Failed to delete stream');
  }
}

/**
 * Log stream activity
 */
export async function logStreamActivity(activity: Omit<StreamActivity, 'id' | 'timestamp'>): Promise<void> {
  const { error } = await supabaseAdmin
    .from('stream_activity')
    .insert({
      stream_id: activity.streamId,
      event_type: activity.eventType,
      metadata: activity.metadata,
    });

  if (error) {
    console.error('Error logging stream activity:', error);
    // Don't throw - activity logging should not break main flow
  }
}

/**
 * Get listener count for a stream (from recent activity)
 */
export async function getListenerCount(streamId: string): Promise<number> {
  const { data, error } = await supabaseAdmin
    .rpc('get_listener_count', { stream_uuid: streamId });

  if (error) {
    console.error('Error getting listener count:', error);
    return 0;
  }

  return data || 0;
}

/**
 * Get streams by DJ wallet address
 */
export async function getStreamsByDj(djWalletAddress: string): Promise<Stream[]> {
  return getStreams({ djWalletAddress });
}
