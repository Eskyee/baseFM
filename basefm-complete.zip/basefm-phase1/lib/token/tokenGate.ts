// lib/token/tokenGate.ts
import { createPublicClient, http, Address } from 'viem';
import { base } from 'viem/chains';

// ERC-20 ABI (balanceOf function)
const ERC20_ABI = [
  {
    constant: true,
    inputs: [{ name: '_owner', type: 'address' }],
    name: 'balanceOf',
    outputs: [{ name: 'balance', type: 'uint256' }],
    type: 'function',
  },
  {
    constant: true,
    inputs: [],
    name: 'decimals',
    outputs: [{ name: '', type: 'uint8' }],
    type: 'function',
  },
  {
    constant: true,
    inputs: [],
    name: 'symbol',
    outputs: [{ name: '', type: 'string' }],
    type: 'function',
  },
  {
    constant: true,
    inputs: [],
    name: 'name',
    outputs: [{ name: '', type: 'string' }],
    type: 'function',
  },
] as const;

// ERC-721 ABI (balanceOf function)
const ERC721_ABI = [
  {
    constant: true,
    inputs: [{ name: '_owner', type: 'address' }],
    name: 'balanceOf',
    outputs: [{ name: '', type: 'uint256' }],
    type: 'function',
  },
  {
    constant: true,
    inputs: [],
    name: 'symbol',
    outputs: [{ name: '', type: 'string' }],
    type: 'function',
  },
  {
    constant: true,
    inputs: [],
    name: 'name',
    outputs: [{ name: '', type: 'string' }],
    type: 'function',
  },
] as const;

// Create public client for Base
const publicClient = createPublicClient({
  chain: base,
  transport: http(process.env.NEXT_PUBLIC_BASE_RPC_URL),
});

export interface TokenInfo {
  address: Address;
  name: string;
  symbol: string;
  decimals?: number;
  type: 'ERC20' | 'ERC721';
}

export interface TokenBalanceResult {
  hasAccess: boolean;
  balance: bigint;
  formattedBalance: string;
  required: bigint;
  tokenInfo: TokenInfo;
}

/**
 * Check if address has sufficient ERC-20 token balance
 */
export async function checkERC20Balance(
  tokenAddress: Address,
  walletAddress: Address,
  requiredAmount: number
): Promise<TokenBalanceResult> {
  try {
    // Get token info
    const [name, symbol, decimals, balance] = await Promise.all([
      publicClient.readContract({
        address: tokenAddress,
        abi: ERC20_ABI,
        functionName: 'name',
      }),
      publicClient.readContract({
        address: tokenAddress,
        abi: ERC20_ABI,
        functionName: 'symbol',
      }),
      publicClient.readContract({
        address: tokenAddress,
        abi: ERC20_ABI,
        functionName: 'decimals',
      }),
      publicClient.readContract({
        address: tokenAddress,
        abi: ERC20_ABI,
        functionName: 'balanceOf',
        args: [walletAddress],
      }),
    ]);

    // Convert required amount to token units
    const requiredBigInt = BigInt(Math.floor(requiredAmount * 10 ** Number(decimals)));

    // Format balance for display
    const formattedBalance = formatTokenBalance(balance, Number(decimals));

    return {
      hasAccess: balance >= requiredBigInt,
      balance,
      formattedBalance,
      required: requiredBigInt,
      tokenInfo: {
        address: tokenAddress,
        name: name as string,
        symbol: symbol as string,
        decimals: Number(decimals),
        type: 'ERC20',
      },
    };
  } catch (error) {
    console.error('Error checking ERC-20 balance:', error);
    throw new Error('Failed to check token balance');
  }
}

/**
 * Check if address owns any ERC-721 tokens
 */
export async function checkERC721Balance(
  tokenAddress: Address,
  walletAddress: Address,
  requiredAmount: number = 1
): Promise<TokenBalanceResult> {
  try {
    // Get token info
    const [name, symbol, balance] = await Promise.all([
      publicClient.readContract({
        address: tokenAddress,
        abi: ERC721_ABI,
        functionName: 'name',
      }),
      publicClient.readContract({
        address: tokenAddress,
        abi: ERC721_ABI,
        functionName: 'symbol',
      }),
      publicClient.readContract({
        address: tokenAddress,
        abi: ERC721_ABI,
        functionName: 'balanceOf',
        args: [walletAddress],
      }),
    ]);

    const requiredBigInt = BigInt(requiredAmount);

    return {
      hasAccess: balance >= requiredBigInt,
      balance,
      formattedBalance: balance.toString(),
      required: requiredBigInt,
      tokenInfo: {
        address: tokenAddress,
        name: name as string,
        symbol: symbol as string,
        type: 'ERC721',
      },
    };
  } catch (error) {
    console.error('Error checking ERC-721 balance:', error);
    throw new Error('Failed to check NFT balance');
  }
}

/**
 * Auto-detect token type and check balance
 */
export async function checkTokenAccess(
  tokenAddress: Address,
  walletAddress: Address,
  requiredAmount: number
): Promise<TokenBalanceResult> {
  // Try ERC-20 first
  try {
    const result = await checkERC20Balance(tokenAddress, walletAddress, requiredAmount);
    return result;
  } catch (erc20Error) {
    // If ERC-20 fails, try ERC-721
    try {
      const result = await checkERC721Balance(tokenAddress, walletAddress, requiredAmount);
      return result;
    } catch (erc721Error) {
      console.error('Token check failed for both ERC-20 and ERC-721:', {
        erc20Error,
        erc721Error,
      });
      throw new Error('Unable to verify token. Make sure the address is correct.');
    }
  }
}

/**
 * Format token balance for display
 */
function formatTokenBalance(balance: bigint, decimals: number): string {
  const divisor = BigInt(10 ** decimals);
  const whole = balance / divisor;
  const remainder = balance % divisor;

  // Convert remainder to decimal string
  const remainderStr = remainder.toString().padStart(decimals, '0');
  
  // Trim trailing zeros
  const trimmed = remainderStr.replace(/0+$/, '');
  
  if (trimmed === '') {
    return whole.toString();
  }

  return `${whole}.${trimmed}`;
}

/**
 * Validate token address format
 */
export function isValidTokenAddress(address: string): address is Address {
  return /^0x[a-fA-F0-9]{40}$/.test(address);
}

/**
 * Get token info without checking balance
 */
export async function getTokenInfo(tokenAddress: Address): Promise<TokenInfo> {
  try {
    // Try ERC-20 first
    const [name, symbol, decimals] = await Promise.all([
      publicClient.readContract({
        address: tokenAddress,
        abi: ERC20_ABI,
        functionName: 'name',
      }),
      publicClient.readContract({
        address: tokenAddress,
        abi: ERC20_ABI,
        functionName: 'symbol',
      }),
      publicClient.readContract({
        address: tokenAddress,
        abi: ERC20_ABI,
        functionName: 'decimals',
      }),
    ]);

    return {
      address: tokenAddress,
      name: name as string,
      symbol: symbol as string,
      decimals: Number(decimals),
      type: 'ERC20',
    };
  } catch (error) {
    // Try ERC-721
    try {
      const [name, symbol] = await Promise.all([
        publicClient.readContract({
          address: tokenAddress,
          abi: ERC721_ABI,
          functionName: 'name',
        }),
        publicClient.readContract({
          address: tokenAddress,
          abi: ERC721_ABI,
          functionName: 'symbol',
        }),
      ]);

      return {
        address: tokenAddress,
        name: name as string,
        symbol: symbol as string,
        type: 'ERC721',
      };
    } catch (erc721Error) {
      throw new Error('Unable to fetch token info. Invalid token address.');
    }
  }
}
