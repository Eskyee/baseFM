# baseFM Production Deployment Checklist

## ✅ Pre-Deployment

### Supabase Setup
- [ ] Project created
- [ ] Database schema applied (supabase-schema.sql)
- [ ] Tables verified: streams, events, stream_activity
- [ ] Views created: live_streams, upcoming_events
- [ ] RLS policies enabled and tested
- [ ] API keys copied to .env.local

### Mux Setup
- [ ] Account created
- [ ] Access token generated (Video Read+Write)
- [ ] Token ID and Secret copied
- [ ] Webhook endpoint planned (will update after Vercel deploy)
- [ ] Webhook secret copied

### Code Setup
- [ ] Repository created on GitHub
- [ ] All files committed
- [ ] .env.local configured (NOT committed)
- [ ] package.json dependencies reviewed

## ✅ Vercel Deployment

### Initial Deploy
- [ ] GitHub repo imported to Vercel
- [ ] Framework detected as Next.js
- [ ] All environment variables added:
  - [ ] NEXT_PUBLIC_SUPABASE_URL
  - [ ] NEXT_PUBLIC_SUPABASE_ANON_KEY
  - [ ] SUPABASE_SERVICE_ROLE_KEY
  - [ ] MUX_TOKEN_ID
  - [ ] MUX_TOKEN_SECRET
  - [ ] MUX_WEBHOOK_SECRET
  - [ ] NEXT_PUBLIC_BASE_CHAIN_ID=8453
  - [ ] NEXT_PUBLIC_BASE_RPC_URL=https://mainnet.base.org
  - [ ] NEXT_PUBLIC_APP_URL (set to your Vercel domain)

### Post-Deploy
- [ ] Deployment successful
- [ ] Visit https://your-project.vercel.app
- [ ] API route test: /api/streams (should return empty array)
- [ ] Mux webhook updated to: https://your-project.vercel.app/api/webhooks/mux

## ✅ Testing

### API Endpoints
Test each endpoint with curl or Postman:

```bash
# List streams (should be empty initially)
curl https://your-domain.com/api/streams

# Create test stream
curl -X POST https://your-domain.com/api/streams \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test Stream",
    "djName": "Test DJ",
    "djWalletAddress": "0x1234567890123456789012345678901234567890"
  }'

# Get live streams
curl https://your-domain.com/api/streams/live
```

### Mux Integration
- [ ] Create stream via API
- [ ] Verify Mux live stream created in dashboard
- [ ] Test RTMP connection with OBS:
  - Server: `rtmps://global-live.mux.com:443/app`
  - Stream Key: [from API response]
- [ ] Verify webhook fired when stream goes active
- [ ] Check stream status updated to LIVE in database
- [ ] Disconnect OBS
- [ ] Verify status updated to ENDING then ENDED

### Database
- [ ] Check streams table has records
- [ ] Check stream_activity logs created
- [ ] Test listener count function
- [ ] Verify RLS policies (try reading with anon key)

## ✅ Production Hardening

### Security
- [ ] Rate limiting added (consider Vercel Edge Config)
- [ ] Wallet signature verification enabled
- [ ] CORS policies configured
- [ ] API route authentication for sensitive operations
- [ ] Environment variables secured (never in git)

### Monitoring
- [ ] Vercel Analytics enabled
- [ ] Error tracking (Sentry/Bugsnag optional)
- [ ] Database monitoring (Supabase dashboard)
- [ ] Mux usage monitoring (Mux dashboard)

### Performance
- [ ] API routes respond < 500ms
- [ ] HLS playback starts < 3s
- [ ] Database queries optimized
- [ ] Proper indexes verified

### Documentation
- [ ] README updated with production URLs
- [ ] API documentation complete
- [ ] DJ onboarding guide created
- [ ] Troubleshooting guide available

## ✅ Custom Domain (Optional)

If using custom domain:
- [ ] Domain added in Vercel
- [ ] DNS records configured
- [ ] SSL certificate active
- [ ] NEXT_PUBLIC_APP_URL updated
- [ ] Mux webhook URL updated to custom domain

## ✅ Launch

### Pre-Launch
- [ ] Test stream scheduled
- [ ] DJ briefed on workflow
- [ ] Support channels ready
- [ ] Backup plan if Mux fails

### Launch Day
- [ ] Monitor Vercel logs
- [ ] Monitor Supabase logs
- [ ] Monitor Mux dashboard
- [ ] Test listener experience
- [ ] Verify webhooks working

### Post-Launch
- [ ] User feedback collected
- [ ] Performance metrics reviewed
- [ ] Any errors addressed
- [ ] Next phase planned

## 🔧 Rollback Plan

If critical issues occur:

1. **Vercel**: Click "Rollback" to previous deployment
2. **Database**: Restore from Supabase backup (automatic daily)
3. **Mux**: Streams persist, can recreate in dashboard if needed

## 📞 Emergency Contacts

- Vercel Status: https://vercel-status.com
- Supabase Status: https://status.supabase.com
- Mux Status: https://status.mux.com

## 📝 Notes

Deployment Date: _______________
Deployed By: _______________
Production URL: _______________
Issues Encountered: _______________
