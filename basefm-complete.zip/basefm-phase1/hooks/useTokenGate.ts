// hooks/useTokenGate.ts
'use client';

import { useState, useEffect } from 'react';
import { useAccount } from 'wagmi';
import { checkTokenAccess, type TokenBalanceResult } from '@/lib/token/tokenGate';
import type { Address } from 'viem';

export interface UseTokenGateOptions {
  tokenAddress?: string;
  requiredAmount?: number;
  enabled?: boolean; // Whether to check automatically
}

export interface UseTokenGateResult {
  hasAccess: boolean;
  isChecking: boolean;
  error: string | null;
  tokenInfo: TokenBalanceResult | null;
  checkAccess: () => Promise<void>;
}

/**
 * Hook to check if connected wallet has required token balance
 */
export function useTokenGate(options: UseTokenGateOptions = {}): UseTokenGateResult {
  const { tokenAddress, requiredAmount = 1, enabled = true } = options;
  const { address, isConnected } = useAccount();

  const [hasAccess, setHasAccess] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tokenInfo, setTokenInfo] = useState<TokenBalanceResult | null>(null);

  const checkAccess = async () => {
    // Reset state
    setError(null);
    setHasAccess(false);
    setTokenInfo(null);

    // Validation
    if (!isConnected || !address) {
      setError('Please connect your wallet');
      return;
    }

    if (!tokenAddress) {
      setError('No token address specified');
      return;
    }

    if (!tokenAddress.match(/^0x[a-fA-F0-9]{40}$/)) {
      setError('Invalid token address');
      return;
    }

    setIsChecking(true);

    try {
      const result = await checkTokenAccess(
        tokenAddress as Address,
        address as Address,
        requiredAmount
      );

      setTokenInfo(result);
      setHasAccess(result.hasAccess);

      if (!result.hasAccess) {
        setError(
          `Insufficient balance. You need ${requiredAmount} ${result.tokenInfo.symbol}, but you have ${result.formattedBalance}`
        );
      }
    } catch (err) {
      console.error('Error checking token access:', err);
      const message = err instanceof Error ? err.message : 'Failed to check token balance';
      setError(message);
      setHasAccess(false);
    } finally {
      setIsChecking(false);
    }
  };

  // Auto-check when dependencies change (if enabled)
  useEffect(() => {
    if (enabled && tokenAddress && isConnected && address) {
      checkAccess();
    }
  }, [tokenAddress, requiredAmount, address, isConnected, enabled]);

  return {
    hasAccess,
    isChecking,
    error,
    tokenInfo,
    checkAccess,
  };
}
