// hooks/useStreams.ts
'use client';

import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase/client';
import type { Stream, StreamStatus } from '@/types/stream';

export interface UseStreamsOptions {
  status?: StreamStatus;
  djWalletAddress?: string;
  limit?: number;
  autoRefresh?: boolean; // Auto-refresh every N seconds
  refreshInterval?: number; // Default 30s
}

export interface UseStreamsResult {
  streams: Stream[];
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

/**
 * Hook to fetch multiple streams with optional filters
 * Optionally subscribes to realtime updates
 */
export function useStreams(options: UseStreamsOptions = {}): UseStreamsResult {
  const {
    status,
    djWalletAddress,
    limit = 50,
    autoRefresh = false,
    refreshInterval = 30000, // 30 seconds
  } = options;

  const [streams, setStreams] = useState<Stream[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStreams = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Build query params
      const params = new URLSearchParams();
      if (status) params.append('status', status);
      if (djWalletAddress) params.append('djWalletAddress', djWalletAddress);
      if (limit) params.append('limit', limit.toString());

      const response = await fetch(`/api/streams?${params.toString()}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch streams');
      }

      const data = await response.json();
      setStreams(data.streams);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      setError(message);
      setStreams([]);
    } finally {
      setIsLoading(false);
    }
  }, [status, djWalletAddress, limit]);

  // Initial fetch
  useEffect(() => {
    fetchStreams();
  }, [fetchStreams]);

  // Auto-refresh interval
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      fetchStreams();
    }, refreshInterval);

    return () => clearInterval(interval);
  }, [autoRefresh, refreshInterval, fetchStreams]);

  // Subscribe to realtime updates for all streams
  useEffect(() => {
    const channel = supabase
      .channel('streams-all')
      .on(
        'postgres_changes',
        {
          event: '*', // INSERT, UPDATE, DELETE
          schema: 'public',
          table: 'streams',
        },
        (payload) => {
          console.log('Streams table changed:', payload.eventType);
          // Refetch to get latest data
          fetchStreams();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchStreams]);

  return {
    streams,
    isLoading,
    error,
    refetch: fetchStreams,
  };
}

/**
 * Hook specifically for live streams
 * Auto-refreshes every 10 seconds
 */
export function useLiveStreams(): UseStreamsResult {
  const [streams, setStreams] = useState<Stream[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchLiveStreams = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch('/api/streams/live');
      
      if (!response.ok) {
        throw new Error('Failed to fetch live streams');
      }

      const data = await response.json();
      setStreams(data.streams);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      setError(message);
      setStreams([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Initial fetch
  useEffect(() => {
    fetchLiveStreams();
  }, [fetchLiveStreams]);

  // Auto-refresh every 10 seconds for live streams
  useEffect(() => {
    const interval = setInterval(() => {
      fetchLiveStreams();
    }, 10000);

    return () => clearInterval(interval);
  }, [fetchLiveStreams]);

  // Subscribe to realtime updates
  useEffect(() => {
    const channel = supabase
      .channel('live-streams')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'streams',
        },
        (payload) => {
          console.log('Live streams updated:', payload.eventType);
          fetchLiveStreams();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchLiveStreams]);

  return {
    streams,
    isLoading,
    error,
    refetch: fetchLiveStreams,
  };
}
