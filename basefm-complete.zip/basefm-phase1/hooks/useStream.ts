// hooks/useStream.ts
'use client';

import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase/client';
import type { Stream } from '@/types/stream';

export interface UseStreamResult {
  stream: Stream | null;
  isLive: boolean;
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

/**
 * Hook to fetch and subscribe to a single stream
 * Automatically updates when stream status changes via Supabase realtime
 */
export function useStream(streamId: string | null): UseStreamResult {
  const [stream, setStream] = useState<Stream | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStream = useCallback(async () => {
    if (!streamId) {
      setStream(null);
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`/api/streams/${streamId}`);
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Stream not found');
        }
        throw new Error('Failed to fetch stream');
      }

      const data = await response.json();
      setStream(data.stream);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      setError(message);
      setStream(null);
    } finally {
      setIsLoading(false);
    }
  }, [streamId]);

  // Initial fetch
  useEffect(() => {
    fetchStream();
  }, [fetchStream]);

  // Subscribe to realtime updates
  useEffect(() => {
    if (!streamId) return;

    const channel = supabase
      .channel(`stream:${streamId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'streams',
          filter: `id=eq.${streamId}`,
        },
        (payload) => {
          console.log('Stream updated:', payload);
          // Update local state with new data
          setStream((prev) => {
            if (!prev) return null;
            return {
              ...prev,
              ...mapDbRowToStream(payload.new),
            };
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [streamId]);

  return {
    stream,
    isLive: stream?.status === 'LIVE',
    isLoading,
    error,
    refetch: fetchStream,
  };
}

/**
 * Convert snake_case database row to camelCase Stream object
 */
function mapDbRowToStream(row: any): Partial<Stream> {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    djName: row.dj_name,
    djWalletAddress: row.dj_wallet_address,
    status: row.status,
    muxLiveStreamId: row.mux_live_stream_id,
    muxStreamKey: row.mux_stream_key,
    muxPlaybackId: row.mux_playback_id,
    rtmpUrl: row.rtmp_url,
    hlsPlaybackUrl: row.hls_playback_url,
    scheduledStartTime: row.scheduled_start_time,
    actualStartTime: row.actual_start_time,
    actualEndTime: row.actual_end_time,
    isGated: row.is_gated,
    requiredTokenAddress: row.required_token_address,
    requiredTokenAmount: row.required_token_amount,
    coverImageUrl: row.cover_image_url,
    genre: row.genre,
    tags: row.tags,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}
